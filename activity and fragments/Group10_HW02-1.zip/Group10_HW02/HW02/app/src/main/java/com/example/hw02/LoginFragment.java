// Gowri Alwarsamy
// Saranya Thirumoorthy

package com.example.hw02;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class LoginFragment extends Fragment {

    public static final String LOGIN = "LOGIN";
    public static final String SIGNUP = "SIGNUP";

    EditText idLabel, pwLabel;
    Button loginButton;
    TextView signupLink;
    String loginID ="", password ="", errorMsg ="";
    LoginListener listener;


    public LoginFragment() {
     }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        if(context instanceof LoginListener) {
            listener = (LoginListener) context;
        }
        else
            throw new RuntimeException(context.toString());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);

         idLabel = view.findViewById(R.id.loginEmailField);
         pwLabel = view.findViewById(R.id.loginPwField);
         loginButton = view.findViewById(R.id.loginBtn);
         signupLink = view.findViewById(R.id.createNewBtn);

         signupLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.performLogin(loginID, password, SIGNUP);
            }
         });

         loginButton.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 performValidation();
             }
         });

         return view;
    }


    @Override
    public void onResume() {
        super.onResume();
        System.out.println("login resumed");
    }

    public void performValidation() {

        loginID = idLabel.getText().toString();
        password = pwLabel.getText().toString();
        errorMsg ="";

        if(loginID.isEmpty()) {
            concatError(getResources().getString(R.string.name_err));
        }
        if(password.isEmpty()) {
            concatError(getResources().getString(R.string.pw_error));
        }


        if (errorMsg != null && !errorMsg.isEmpty()) {
            // show error message
            showToast(errorMsg);
        } else {
            listener.performLogin(loginID, password, LOGIN);
        }
    }

    public void showToast(String message) {
        Toast.makeText(getActivity(),message,Toast.LENGTH_LONG).show();
    }


    public void concatError(String errMsg) {
        if (errorMsg.isEmpty()) {
            errorMsg = errMsg;
        }
        else {
            errorMsg = errorMsg.concat(getResources().getString(R.string.comma)).concat(errMsg);
        }
    }


    public interface LoginListener {
        // interface for login

        void performLogin(String email, String passcode, String action);
    }

}



