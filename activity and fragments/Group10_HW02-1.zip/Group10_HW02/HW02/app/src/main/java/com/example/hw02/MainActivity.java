//Group10_HW02
//MainActivity.java
// Gowri Alwarsamy
// Saranya Thirumoorthy

package com.example.hw02;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;


public class MainActivity extends AppCompatActivity implements LoginFragment.LoginListener, AccountFragment.AccountListener,
        RegisterFragment.SignupListener, UpdateFragment.UpdateListener {

    DataServices.Account currAccount;
    String loginName, password, action,name,email;

    private static String LOGIN_FRAG = "LOGIN_FRAG";
    private static String UPDATE_FRAG = "UPDATE_FRAG";
    private static String SIGNUP_FRAG = "SIGNUP_FRAG";
    private static String ACCOUNT_FRAG = "ACCOUNT_FRAG";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle(getString(R.string.login));
        getSupportFragmentManager().beginTransaction().
                add(R.id.containerView, new LoginFragment(), LOGIN_FRAG).commit();
    }

    public void showToast(String message) {
        Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void performLogin(String name, String pw, String action) {
        this.loginName = name;
        this.password = pw;
        this.action = action;

        if (action.equals(LoginFragment.LOGIN)) {
            // user clicked login
            DataServices.Account account = DataServices.login(name, pw);
            if (account != null) {
                // login successfull
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.containerView, AccountFragment.newInstance(account), ACCOUNT_FRAG)
                        .commit();
                setTitle(getString(R.string.account_title));
            } else {
                showToast(getString(R.string.login_err));
            }
        }

        else if (action.equals(LoginFragment.SIGNUP)) {
            // user clicked sign up
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.containerView, new RegisterFragment(), SIGNUP_FRAG)
                    .commit();
            setTitle(getString(R.string.signup_header));
            Toast.makeText(MainActivity.this,"message",Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    public void performSignupAction(String name, String email, String pw, String action) {
        this.name = name;
        this.password = pw;
        this.email = email;

        if (action.equals(RegisterFragment.CANCEL)) {
            // sign up cancelled
            getSupportFragmentManager().beginTransaction().
                    replace(R.id.containerView, new LoginFragment(), LOGIN_FRAG).commit();
            setTitle(getString(R.string.login));

        } else if (action.equals(RegisterFragment.SIGNUP)) {

            currAccount = DataServices.register(name, email, pw);
            if (currAccount != null) {
                //sign up successful

                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.containerView, AccountFragment.newInstance(currAccount), ACCOUNT_FRAG)
                        .commit();
                setTitle(getString(R.string.account_title));
            }
            else
                showToast(getString(R.string.acct_exists));

        }
    }


    @Override
    public void performAccountAction(String action, DataServices.Account account) {
        this.currAccount = account;

        if (action.equals(AccountFragment.LOGOUT)) {
            //logout action

            if(account instanceof DataServices.Account) {
                account = null;// clear the object
            }
            getSupportFragmentManager().beginTransaction().
                    replace(R.id.containerView, new LoginFragment(), LOGIN_FRAG).commit();
            setTitle(getString(R.string.login));

        } else if (action.equals(AccountFragment.EDITPROFILE)) {
            // edit profile

            getSupportFragmentManager().beginTransaction().
                    replace(R.id.containerView, UpdateFragment.newInstance(account), UPDATE_FRAG)
                    .addToBackStack(null)
                    .commit();
            setTitle(getString(R.string.update_profile));
        }

    }


    @Override
    public void performUpdateAction(DataServices.Account account, String name, String pw, String action) {
        this.action = action;
        this.password = pw;
        this.name = name;
        this.currAccount = account;


        if (action.equals(UpdateFragment.CANCEL)) {
            // update cancelled

            getSupportFragmentManager().popBackStack();
            setTitle(getString(R.string.account_title));
        } else if (action.equals(UpdateFragment.UPDATE)) {

            account = DataServices.update(account, name, pw);
            if (account != null) {
                // update successful

                AccountFragment accountFt = (AccountFragment) getSupportFragmentManager().findFragmentByTag(ACCOUNT_FRAG);
                // updates new account object to AccountFragment
                accountFt.updateAccount(account);
                getSupportFragmentManager().popBackStack(); // pops back to account frag
                setTitle(getString(R.string.account_title));
            }
        }
    }
}