// Gowri Alwarsamy
// Saranya Thirumoorthy

package com.example.hw02;

import androidx.annotation.NonNull;
import android.view.LayoutInflater;
import androidx.fragment.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.View;

public class AccountFragment extends Fragment {

    TextView nameLabel;
    Button editBtn, logoutBtn;
    View view;
    AccountListener listener;
    DataServices.Account currAccount;

    public static final String LOGOUT = "LOGOUT";
    public static final String EDITPROFILE = "EDITPROFILE";
    private static final String PARAM1 = "param1";


    public AccountFragment() {
        // Required empty public constructor
    }


    public static AccountFragment newInstance(DataServices.Account account) {
        // #check
         AccountFragment fm = new AccountFragment();
         Bundle args = new Bundle();
         args.putSerializable(PARAM1, account);
         fm.setArguments(args);
         return fm;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            this.currAccount = (DataServices.Account) getArguments().get(PARAM1);
        }
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        if(context instanceof AccountListener) {
            listener = (AccountListener) context;
        }
        else
            throw new RuntimeException(context.toString());
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d("checkhere", "onResume: " + currAccount.getName());
        nameLabel.setText(currAccount.getName());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_account, container, false);
        logoutBtn = view.findViewById(R.id.logoutBtn);
        nameLabel = view.findViewById(R.id.welcomeNameLabel);
        editBtn = view.findViewById(R.id.editProfileBtn);
        nameLabel.setText(currAccount.getName());


        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.performAccountAction(LOGOUT, currAccount);
            }
        });

        editBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.performAccountAction(EDITPROFILE, currAccount);
            }
        });


        return view;
    }


    public void updateAccount(DataServices.Account acct) {
        this.currAccount = acct;
//        view.findViewById(R.id.displayName); //#check need
//        System.out.println(" checkhere " + account.getName());
//        Log.d("checkhere in acctfm", "updateAccount: " + account.getName());
    }


    public interface AccountListener {
        void performAccountAction(String action, DataServices.Account account);
    }
}