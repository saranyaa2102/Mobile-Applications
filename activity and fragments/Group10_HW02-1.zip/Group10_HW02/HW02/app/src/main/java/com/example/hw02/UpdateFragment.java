// Gowri Alwarsamy
// Saranya Thirumoorthy

package com.example.hw02;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class UpdateFragment extends Fragment {

    public static final String CANCEL = "CANCEL";
    public static final String UPDATE = "UPDATE";
    String namePattern = "^[a-zA-Z\\s]*$";

    private static final String PARAM1 = "PARAM1";
    private static final String PARAM2 = "PARAM2";

    DataServices.Account currAccount;
    UpdateListener listener;

    Button submitBtn, cancelBtn;
    EditText nameField, pwField;
    TextView emailLabel;


    String errorMsg = "";
    String name, password;


    public UpdateFragment() {
        // Required empty public constructor
    }


    public static UpdateFragment newInstance(DataServices.Account account) {
        UpdateFragment fm = new UpdateFragment();
        Bundle args = new Bundle();
        args.putSerializable(PARAM1, account);
        fm.setArguments(args);
        return fm;
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        if (context instanceof UpdateListener) {
            listener = (UpdateListener) context;
        } else
            throw new RuntimeException(context.toString());
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            currAccount = (DataServices.Account) getArguments().getSerializable(PARAM1);
            Log.d("checkhere", currAccount.getName() + currAccount.getEmail());
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_update, container, false);


        nameField = view.findViewById(R.id.nameUpdateField);
        pwField = view.findViewById(R.id.pwUpdatefield);
        submitBtn = view.findViewById(R.id.updateProfileBtn);
        cancelBtn = view.findViewById(R.id.cancelUpdateBtn);
        emailLabel = view.findViewById(R.id.emailDisplayLabel);

        pwField.setText(currAccount.getPassword());
        emailLabel.setText(currAccount.getEmail());
        nameField.setText(currAccount.getName());

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performValidation();
            }
        });

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
// call listener on cancel action
                listener.performUpdateAction(currAccount, name, password, CANCEL);

            }
        });

        return view;
    }

    public void performValidation() {
        errorMsg = "";
        password = pwField.getText().toString();
        name = nameField.getText().toString();

        if (name.isEmpty()) {
            concantError(getResources().getString(R.string.name_err));
        } else if (!name.matches(namePattern)) {
            concantError(getResources().getString(R.string.invalid_name));
        }

        if (password.isEmpty()) {
            concantError(getResources().getString(R.string.pw_error));
        }

        if (errorMsg != null && !errorMsg.isEmpty()) {
            showMessage(errorMsg);

        } else {

            // no error call update action in listener
            listener.performUpdateAction(currAccount, name, password, UPDATE);

        }


    }

    public void showMessage(String message) {
        Toast.makeText(getActivity(), message, Toast.LENGTH_LONG).show();
    }

    public void concantError(String errMsg) {

        if (errorMsg.isEmpty()) {
            errorMsg = errMsg;
        } else
            errorMsg = errorMsg.concat(getResources().getString(R.string.comma)).concat(errMsg);
    }


    public interface UpdateListener {
        void performUpdateAction(DataServices.Account account, String name, String passcode, String action);
    }
}