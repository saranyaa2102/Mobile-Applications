// Gowri Alwarsamy
// Saranya Thirumoorthy

package com.example.hw02;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import android.view.ViewGroup;
import android.view.View;


public class RegisterFragment extends Fragment {
    public static String SIGNUP = "SIGNUP";
    public static String CANCEL = "CANCEL";

    SignupListener listener;
    EditText nameField, emailField, pwField;
    TextView cancelBn;
    Button submitBtn;
    String errorMsg = "", name = "",password = "",email = "";
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+", namePattern = "^[a-zA-Z\\s]*$";


    public RegisterFragment() {
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        if (context instanceof SignupListener) {

            listener = (SignupListener) context;

        } else
            throw new RuntimeException(context.toString());

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_register, container, false);
        nameField = view.findViewById(R.id.signupNamefield);
        pwField = view.findViewById(R.id.signupPwField);
        emailField = view.findViewById(R.id.signupEmailField);
        submitBtn = view.findViewById(R.id.signupBtn);
        cancelBn = view.findViewById(R.id.cancelSignupBtn);

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                performValidation();
            }
        });

        cancelBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email = emailField.getText().toString();
                password = pwField.getText().toString();
                name = nameField.getText().toString();

                listener.performSignupAction(name, email, password, CANCEL);
            }
        });
        return view;
    }

    public void performValidation() {
        errorMsg = "";

        password = pwField.getText().toString();
        name = nameField.getText().toString();
        email = emailField.getText().toString();

        if (name.isEmpty()) {
            concatError(getResources().getString(R.string.enter_name));
        } else if (!name.matches(namePattern)) {
            concatError(getResources().getString(R.string.invalid_name));
        }

        if (email.isEmpty()) {
            concatError(getResources().getString(R.string.enter_email));
        } else if (!email.trim().matches(emailPattern)) {
            concatError(getResources().getString(R.string.invalid_email));
        }

        if (password.isEmpty()) {
            concatError(getResources().getString(R.string.ener_pw_emtpy));
        }
        if (errorMsg != null && !errorMsg.isEmpty()) {
            // error present. shows error
            showMessage(errorMsg);

        } else {
            // call signup actions on listener
            listener.performSignupAction(name, email, password, SIGNUP);
        }

    }

    public void showMessage(String message) {

        Toast.makeText(getActivity(), message, Toast.LENGTH_LONG).show();
    }


    public void concatError(String errMsg) {

        if (errorMsg.isEmpty()) {

            errorMsg = errMsg;
        } else
            errorMsg = errorMsg.concat(getResources().getString(R.string.comma)).concat(errMsg);
    }

    @Override
    public void onResume() {
        super.onResume();
//        Log.d("checkhere", "onResume: " + currAccount.getName());
    }

    public interface SignupListener {
        void performSignupAction(String name, String email, String passcode, String action);
    }
}