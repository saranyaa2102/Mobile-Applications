//GroupB10-Inclass05
//KamalaPriya Srinivasan
//Saranyaa Thirumoorthy
//MainActivity.java


package com.example.inclass5;

import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    ListView averageList;
    SeekBar threadRange;
    TextView seekbarProgress;
    TextView threadProgress;
    TextView Avg;
    int ThreadProgress;
    int progressValues;
    ArrayList<Double> averageNumbers = new ArrayList<>();
    ArrayAdapter<Double> averageNumbersDisplayAdapter;
    Handler threadQueueHandler;
    ExecutorService numberGenerationPool;
    ProgressBar PB;
    double randomNumberSum, randomNumberAverage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        PB = findViewById(R.id.PB);
        PB.setVisibility(View.INVISIBLE);
        seekbarProgress = findViewById(R.id.SBValue );
        threadRange = findViewById(R.id.SB);

        numberGenerationPool = Executors.newFixedThreadPool(2);
        threadProgress = findViewById(R.id.threadProgress);
        Avg = findViewById(R.id.average);
        averageList = findViewById(R.id.averageList);
        setTitle (R.string.title ) ;

        threadRange.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                ThreadProgress = progress;
                if (ThreadProgress == 0){
                    seekbarProgress.setText("");
                }
                else{
                    seekbarProgress.setText(getString ( R.string.outputSetText,ThreadProgress) );
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                randomNumberSum = 0;
                randomNumberAverage = 0;
                averageNumbers.clear();
                threadProgress.setText("");
                Avg.setText("");
                averageNumbersDisplayAdapter.notifyDataSetChanged();
                PB.setVisibility(View.INVISIBLE);
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });


        findViewById(R.id.ThreadTask).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                randomNumberSum = 0;
                randomNumberAverage = 0;
                averageNumbers.clear();
                threadProgress.setText("");
                Avg.setText("");
                averageNumbersDisplayAdapter.notifyDataSetChanged();
                if (ThreadProgress == 0){
                    writeToast ( getResources ().getString ( R.string.selectThreadCount ) );
                }
                else{
                    threadRange.setEnabled(false);
                    findViewById(R.id.ThreadTask).setEnabled(false);
                    findViewById(R.id.asyncTask).setEnabled(false);
                    numberGenerationPool.execute(new generateUsingThread());
                }

            }
        });


        findViewById(R.id.asyncTask).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                averageNumbersDisplayAdapter.notifyDataSetChanged();
                averageNumbers.clear();
                Avg.setText("");
                threadProgress.setText("");
                randomNumberSum = 0;
                randomNumberAverage = 0;

                if (ThreadProgress == 0){
                    writeToast ( getResources().getString(R.string.selectThreadCount) );
                }
                else{
                    new generateUsingAsyncTask().execute(ThreadProgress);
                }
            }
        });

        averageNumbersDisplayAdapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, android.R.id.text1, averageNumbers);
        averageList.setAdapter(averageNumbersDisplayAdapter);

        threadQueueHandler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(@NonNull Message message) {
                PB.setVisibility(View.VISIBLE);
                int value = message.getData().getInt(generateUsingThread.INDEX_KEY) + 1;
                PB.setMax(ThreadProgress);
                PB.setProgress(value);
                threadProgress.setText(value + "/" + ThreadProgress);
                Avg.setText(getString ( R.string.outputAverageText,message.getData().getDouble(generateUsingThread.AVERAGE_KEY)));
                if (value == ThreadProgress){
                    threadRange.setEnabled(true);
                    findViewById(R.id.ThreadTask).setEnabled(true);
                    findViewById(R.id.asyncTask).setEnabled(true);
                }
                averageNumbersDisplayAdapter.notifyDataSetChanged();
                return false;
            }
        });
    }

    class generateUsingThread implements Runnable{
        static final String AVERAGE_KEY = "AVERAGE";
        static final String INDEX_KEY = "INDEX";
        @Override
        public void run() {
            for (int item = 0; item < ThreadProgress; item++){
                averageNumbers.add(HeavyWork.getNumber());
                randomNumberSum += averageNumbers.get(item);
                randomNumberAverage = randomNumberSum / (item + 1);
                Bundle bundle = new Bundle();
                bundle.putInt(INDEX_KEY, item);
                bundle.putDouble(AVERAGE_KEY, randomNumberAverage);
                Message message = new Message();
                message.setData(bundle);
                threadQueueHandler.sendMessage(message);
            }
        }
    }


    class generateUsingAsyncTask extends AsyncTask<Integer, Integer, Double>{
        @Override
        protected Double doInBackground(Integer... integers) {
            for (int item = 0; item < integers[0]; item++){
                averageNumbers.add(HeavyWork.getNumber());
                randomNumberSum += averageNumbers.get(item);
                randomNumberAverage = randomNumberSum / (item + 1);
                publishProgress(item);
            }
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            findViewById(R.id.ThreadTask).setEnabled(false);
            findViewById(R.id.asyncTask).setEnabled(false);
            threadRange.setEnabled(false);
        }

        @Override
        protected void onPostExecute(Double aDouble) {
            super.onPostExecute(aDouble);
            findViewById(R.id.asyncTask).setEnabled(true);
            findViewById(R.id.ThreadTask).setEnabled(true);
            threadRange.setEnabled(true);
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            progressValues=values[0] + 1;
            threadRange.setEnabled(false);
            PB.setMax(ThreadProgress);
            PB.setVisibility(View.VISIBLE);
            PB.setProgress(progressValues);
            threadProgress.setText((progressValues) + "/" + ThreadProgress);
            Avg.setText(getString ( R.string.outputAverageText,randomNumberAverage));
            averageNumbersDisplayAdapter.notifyDataSetChanged();
        }
    }

    public void writeToast(String message){
        Toast.makeText ( this , message , Toast.LENGTH_SHORT ).show ( );
    }
}