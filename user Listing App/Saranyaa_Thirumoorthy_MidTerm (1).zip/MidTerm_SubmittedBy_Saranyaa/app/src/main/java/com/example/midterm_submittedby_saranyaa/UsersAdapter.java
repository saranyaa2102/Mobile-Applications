package com.example.midterm_submittedby_saranyaa;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

public class UsersAdapter extends ArrayAdapter<User>{
    private ArrayList<User> usersList;

    TextView userName,userAge,userState,userGroup;
    ImageView icon;
    public UsersAdapter(@NonNull Context context,@NonNull ArrayList<User> objects) {
        super(context,0,  objects);
        this.usersList = objects;
    }

    public class ViewHolder{
        public ViewHolder(View view){
            userName = view.findViewById(R.id.name);
            userState = view.findViewById(R.id.state);
            userAge = view.findViewById(R.id.age);
            userGroup = view.findViewById(R.id.group);
            icon = view.findViewById(R.id.genderIcon);
        }
    }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder viewHolder;
        User user = getItem(position);
        if(convertView == null){
            convertView = LayoutInflater.from(this.getContext()).inflate(R.layout.users_display,parent,false);
            viewHolder = new ViewHolder(convertView);
            userName.setText(String.valueOf(user.name));
            userAge.setText(String.valueOf(user.age));
            userState.setText(String.valueOf(user.state));
            userGroup.setText(String.valueOf(user.group));
            if(user.gender.equals("Male")) {
                icon.setImageResource(R.drawable.avatar_male);
            } else {
                icon.setImageResource(R.drawable.avatar_female);
            }
            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder) convertView.getTag();
        }
        return convertView;
    }
}
