package com.example.midterm_submittedby_saranyaa;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.lang.reflect.Array;
import java.util.ArrayList;


public class filterByState extends Fragment {

    private static final String ARG_PARAM1_STATES_LIST = "STATES_KEY";
    private static final String ARG_PARAM1_USERS_LIST = "USERS_KEY";
    public ArrayList<String> allStates;
    stateFilter stateFilter;
    ArrayAdapter adapterByState;
    ListView ByState;
    ArrayList<User> userState=new ArrayList<>();

    public filterByState(ArrayList<String> statesList,ArrayList<User> userState) {
         this.allStates = statesList;
         this.userState=userState;
    }

    public static filterByState newInstance(ArrayList<String> ARG_PARAM1,ArrayList<User> ARG_USERS) {
        filterByState fragment = new filterByState(ARG_PARAM1,ARG_USERS);
        Bundle statesbundle = new Bundle();
        statesbundle.putStringArrayList(ARG_PARAM1_STATES_LIST, ARG_PARAM1);
        statesbundle.putSerializable(ARG_PARAM1_USERS_LIST, ARG_USERS);
        fragment.setArguments(statesbundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            allStates = getArguments().getStringArrayList(ARG_PARAM1_STATES_LIST);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.filter_by_state, container, false);
        ByState = view.findViewById(R.id.states);
        adapterByState = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, android.R.id.text1,allStates);
        ByState.setAdapter(adapterByState);
        ByState.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                stateFilter.positionClicked(position,userState);
                adapterByState.notifyDataSetChanged();
            }
        });
        return view;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if(context instanceof filterByState.stateFilter){
            stateFilter = (filterByState.stateFilter)context;
        }else{
            throw new RuntimeException(context.toString()+"must implement IListener1");
        }
    }

    public interface stateFilter {
        void positionClicked(int position,ArrayList<User> users);
    }
}
