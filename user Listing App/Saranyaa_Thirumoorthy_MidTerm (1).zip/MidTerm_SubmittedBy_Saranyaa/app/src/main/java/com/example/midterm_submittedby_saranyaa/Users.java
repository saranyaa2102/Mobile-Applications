package com.example.midterm_submittedby_saranyaa;


import android.content.Context;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Users extends Fragment {
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;

    ListView usersListView;
    UsersAdapter uAdapter;
    ArrayList<User> usersArray;
    userInterface ui;
    public Users(ArrayList<User> users) {
        this.usersArray = users;
    }

    public static Users newInstance(String param1, String param2) {
        Users fragment = new Users(DataServices.getUsers());
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        setHasOptionsMenu(true);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.users, container, false);
        usersListView = view.findViewById(R.id.list_users);
        uAdapter = new UsersAdapter(getContext(),usersArray);
        usersListView.setAdapter(uAdapter);
        return view;
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if(context instanceof Users.userInterface){
            ui = (Users.userInterface)context;
        }else{
            throw new RuntimeException(context.toString()+"must implement IListener1");
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.item1:
                ui.callToFilterFragment(usersArray);
                return true;
            case R.id.item2:
                ui.calltoSortFragment(usersArray);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public interface userInterface{
        void calltoSortFragment(ArrayList<User> usersArray);
        void callToFilterFragment(ArrayList<User> usersArray);
    }
}
