package com.example.midterm_submittedby_saranyaa;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class filterByAge extends Fragment {
    private static final String ARG_PARAM1_STATES_KEY = "STATES_KEY";
    public ArrayList<String> allStates;

    ArrayAdapter adapter;
    ListView listView;

    public filterByAge(ArrayList<String> states) {
        this.allStates = states;
    }

    public filterByAge() {

    }

    public static filterByAge newInstance(ArrayList<String> ARG_PARAM1_STATES) {
        filterByAge fragment = new filterByAge(ARG_PARAM1_STATES);
        Bundle args = new Bundle();
        args.putStringArrayList(ARG_PARAM1_STATES_KEY, ARG_PARAM1_STATES);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            allStates = getArguments().getStringArrayList(ARG_PARAM1_STATES_KEY);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.filter_by_age, container, false);
        return view;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if(context instanceof filterByAge.ageFilter){
            ageFilterObj = (filterByAge.ageFilter)context;
        }else{
            throw new RuntimeException(context.toString()+"must implement IListener1");
        }
    }

    filterByAge.ageFilter ageFilterObj;


    public interface ageFilter {
        void calltoFilterByAgeFragment();
    }
}
