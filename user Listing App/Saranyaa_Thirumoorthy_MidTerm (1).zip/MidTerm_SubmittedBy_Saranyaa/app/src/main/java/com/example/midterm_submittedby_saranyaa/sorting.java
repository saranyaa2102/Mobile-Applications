package com.example.midterm_submittedby_saranyaa;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class sorting extends Fragment{

    String[] sortingTypes={"Age","Name","State"};
    ListView sortingTypesList;
    ArrayAdapter<String[]> sortingAdapter;
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;
    ArrayList<User> users=new ArrayList<> (  );
    MainActivity main;
    public sort sortingInterface;

    public sorting() {
    }
    public sorting(ArrayList<User> users) {
        this.users=users;
    }

    public static sorting newInstance(String param1 , String param2) {
        sorting fragment = new sorting ( );
        Bundle args = new Bundle ( );
        args.putString ( ARG_PARAM1 , param1 );
        args.putString ( ARG_PARAM2 , param2 );
        fragment.setArguments ( args );
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        if (getArguments ( ) != null) {
            mParam1 = getArguments ( ).getString ( ARG_PARAM1 );
            mParam2 = getArguments ( ).getString ( ARG_PARAM2 );
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater , ViewGroup container ,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate ( R.layout.sort , container , false );
        sortingTypesList=(ListView)v.findViewById ( R.id.sortOption );
        sortingAdapter= new ArrayAdapter (getContext (), android.R.layout.simple_list_item_1,android.R.id.text1,sortingTypes);
        sortingTypesList.setAdapter ( sortingAdapter );

        sortingTypesList.setOnItemClickListener ( new AdapterView.OnItemClickListener ( ) {
            @Override
            public void onItemClick(AdapterView<?> parent , View view , int position , long id) {
                String str=sortingTypes[position];

                if(str.equals("Age")){
                    Collections.sort(users, new Comparator<User> () {
                        @Override
                        public int compare(User a, User b) {
                            return a.age-b.age;
                        }
                    });
                }else if(str.equals("Name")){
                    Collections.sort(users, new Comparator<User>() {
                        @Override
                        public int compare(User a, User b) {
                            return a.name.compareTo(b.name);
                        }
                    });
                }else if(str.equals("State")){
                    Collections.sort(users, new Comparator<User>() {
                        @Override
                        public int compare(User a, User b) {
                            return a.state.compareTo(b.state);

                        }
                    });
                }

                System.out.println (users.get (0).name );
                if(users!=null)
                    sortingInterface.callBackToUsersFragment ( users );



            }
        } );
        return v;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if(context instanceof sorting.sort){
            sortingInterface = (sorting.sort)context;
        }else{
            throw new RuntimeException(context.toString());
        }
    }

    public interface sort{
        void callBackToUsersFragment(ArrayList<User> users);
    }
}
