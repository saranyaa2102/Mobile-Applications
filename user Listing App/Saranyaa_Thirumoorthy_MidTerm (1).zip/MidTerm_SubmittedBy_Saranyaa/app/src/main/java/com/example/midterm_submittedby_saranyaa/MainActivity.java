package com.example.midterm_submittedby_saranyaa;
//Saranyaa Thirumoorthy

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;

public class MainActivity extends AppCompatActivity implements Users.userInterface, filterByState.stateFilter,filter.filterInterface, sorting.sort, filterByAge.ageFilter,filterByType.typeFilter {
    ArrayList<String> filteredstates;
    static ArrayList<User> filteredUsers;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        new DataAsync().execute("check");
        setTitle ("Users" ) ;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    public void initialFragment(){
        getSupportFragmentManager().beginTransaction().add(R.id.rootView,new Users(filteredUsers)).commit();
    }


    @Override
    public void calltoFilterByStateFragment(ArrayList<User> users) {
        Set<String> states1 = new TreeSet<>();

        for(User user: users){
            states1.add(user.state);
        }
        filteredstates = new ArrayList<>(states1);
        filteredstates.add(0,"All States");
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.rootView, new filterByState(filteredstates,users))
                .addToBackStack(null)
                .commit();
        setTitle ("Filter By State" ) ;
    }
    @Override
    public void calltoFilterByAgeFragment() {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.rootView, new filterByAge())
                .addToBackStack(null)
                .commit();
        setTitle ("Age Range" ) ;
    }

    @Override
    public void calltoFilterByType() {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.rootView, new filterByType())
                .addToBackStack(null)
                .commit();
        setTitle ("Filter By Type" ) ;
    }


    @Override
    public void calltoSortFragment(ArrayList<User> users) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.rootView, new sorting(users), "SortFragmentTag")
                .addToBackStack(null)
                .commit();
        setTitle ("Sort" ) ;
    }

    @Override
    public void callToFilterFragment(ArrayList<User> users){
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.rootView, new filter(users))
                .addToBackStack(null)
                .commit();
        setTitle ("Filters" );
    }


    @Override
    public void positionClicked(int position,ArrayList<User> users) {
        String selected_State = filteredstates.get(position);
        ArrayList<User> selected = new ArrayList<>();
        if(position == 0) {
            initialFragment();
            setTitle("Users");
        }else{
            for (User user : users) {
                if (user.state.equals(selected_State)) {
                    selected.add(user);
                }
            }
            getSupportFragmentManager().beginTransaction().replace(R.id.rootView, new Users(selected)).commit();
        }
    }


    @Override
    public void callBackToUsersFragment(ArrayList<User> users) {
        getSupportFragmentManager().beginTransaction().replace(R.id.rootView,new Users(users)).commit();
    }

    @Override
    public void calltoFilterByTypeFragment() {

    }


    class DataAsync extends AsyncTask<String,String,ArrayList<User>> {
        @Override
        protected ArrayList<User> doInBackground(String... strings) {
            return null;
        }

        @Override
        protected void onPostExecute(ArrayList<User> users) {
            super.onPostExecute(users);
            initialFragment();
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            filteredUsers = DataServices.getUsers();
        }
    }

}
