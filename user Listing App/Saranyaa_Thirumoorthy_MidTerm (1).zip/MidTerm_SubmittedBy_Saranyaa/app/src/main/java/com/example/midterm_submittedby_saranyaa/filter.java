package com.example.midterm_submittedby_saranyaa;
import android.content.Context;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.ArrayList;


public class filter extends Fragment {
        String[] FilterType={"State","Age Range","Type"};
        ListView FilterTypeListView;
        ArrayAdapter<String[]> FilterAdapter;
        ArrayList<User> filterUSer;

        private static final String ARG_PARAM1 = "param1";
        private static final String ARG_PARAM2 = "param2";

        private String mParam1;
        private String mParam2;
        MainActivity main;
        public filter.filterInterface FilterAdapterInterface;


        public filter(){

        }
        public filter(ArrayList<User> users){
                filterUSer=users;
        }
        public static filter newInstance(String param1 , String param2) {
                filter fragment = new filter ( );
                Bundle filterTypes = new Bundle ( );
                filterTypes.putString ( ARG_PARAM1 , param1 );
                filterTypes.putString ( ARG_PARAM2 , param2 );
                fragment.setArguments ( filterTypes );
                return fragment;
        }

        @Override
        public void onCreate(Bundle savedInstanceState) {
                super.onCreate ( savedInstanceState );
                if (getArguments ( ) != null) {
                        mParam1 = getArguments ( ).getString ( ARG_PARAM1 );
                        mParam2 = getArguments ( ).getString ( ARG_PARAM2 );
                }
        }

        @Override
        public View onCreateView(LayoutInflater inflater , ViewGroup container ,
                                 Bundle savedInstanceState) {

                View v= inflater.inflate ( R.layout.filter_options , container , false );
                FilterTypeListView=(ListView)v.findViewById ( R.id.filterOption);
                FilterAdapter= new ArrayAdapter (getContext (), android.R.layout.simple_list_item_1,android.R.id.text1,FilterType);
                FilterTypeListView.setAdapter ( FilterAdapter );

                FilterTypeListView.setOnItemClickListener ( new AdapterView.OnItemClickListener ( ) {
                        @Override
                        public void onItemClick(AdapterView<?> parent , View view , int position , long id) {
                                String str=FilterType[position];
                                if(str.equals("State")){
                                        FilterAdapterInterface.calltoFilterByStateFragment(filterUSer);
                                }else if(str.equals("Age Range")){
                                        FilterAdapterInterface.calltoFilterByAgeFragment();
                                }else if(str.equals("Type")){
                                        FilterAdapterInterface.calltoFilterByType();
                                }
                        }
                } );
                return v;
        }

        @Override
        public void onAttach(@NonNull Context context) {
                super.onAttach(context);
                if(context instanceof filter.filterInterface){
                        FilterAdapterInterface = (filter.filterInterface)context;
                }else{
                        throw new RuntimeException(context.toString());
                }
        }

        public interface filterInterface {
                void calltoFilterByStateFragment(ArrayList<User> users);
                void calltoFilterByAgeFragment();
                void calltoFilterByType();
        }
}

