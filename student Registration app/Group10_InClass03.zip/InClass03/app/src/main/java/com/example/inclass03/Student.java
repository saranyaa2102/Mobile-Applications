//InClass03
//Student.java
//Gowri Alwarsamy
//Saranyaa Thirumoorthy

package com.example.inclass03;

import java.io.Serializable;

public class Student implements Serializable {
    String name, studID, emailID, department;
}
