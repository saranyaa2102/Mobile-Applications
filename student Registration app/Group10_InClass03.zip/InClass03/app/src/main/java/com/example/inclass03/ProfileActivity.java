//InClass03
//ProfileActivity.java
//Gowri Alwarsamy
//Saranyaa Thirumoorthy

package com.example.inclass03;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class ProfileActivity extends AppCompatActivity {

    TextView nameLabel, emailLabel, idLabel, deptLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        nameLabel = findViewById(R.id.nameLabel);
        emailLabel = findViewById(R.id.emailLabel);
        idLabel = findViewById(R.id.idLabel);
        deptLabel = findViewById(R.id.deptLabel);

        Student student = (Student) getIntent().getSerializableExtra(MainActivity.PROFILE_KEY);
        nameLabel.setText(student.name);
        emailLabel.setText(student.emailID);
        idLabel.setText(student.studID);
        deptLabel.setText(student.department);

        setTitle(getString(R.string.profile_page_name));
    }
}