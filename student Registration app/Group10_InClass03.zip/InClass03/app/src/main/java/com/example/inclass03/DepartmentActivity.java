//InClass03
//DepartmentActivity.java
//Gowri Alwarsamy
//Saranyaa Thirumoorthy

package com.example.inclass03;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class DepartmentActivity extends AppCompatActivity {
    public static String deptVal="department";
    RadioGroup radioGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_department);
        radioGroup = findViewById(R.id.radioGroup);
        findViewById(R.id.cancelButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED);
                finish();
            }
        });

        findViewById(R.id.selectButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int checkedID = radioGroup.getCheckedRadioButtonId();
                if (checkedID !=-1){
                    RadioButton selButton = findViewById(checkedID);
                    Intent intent = new Intent();
                    intent.putExtra(deptVal,selButton.getText().toString());
                    setResult(RESULT_OK, intent);
                    finish();
                }else{
                    Toast.makeText(DepartmentActivity.this,getString(R.string.empty_radio_button), Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        });
        setTitle(getString(R.string.dept_page_name));
    }
}
