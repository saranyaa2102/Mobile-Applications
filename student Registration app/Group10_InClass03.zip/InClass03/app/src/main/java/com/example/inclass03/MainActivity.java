//InClass03
//MainActivity.java
//Gowri Alwarsamy
//Saranyaa Thirumoorthy

package com.example.inclass03;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    EditText nameEditText, emaiEditText, idEditText;
    TextView deptTextView;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    String namePattern = "^[a-zA-Z\\s]*$";
    static final String PROFILE_KEY = "PROFILE_KEY";
	final static public int REQ_CODE = 100;//Added Newly


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameEditText = findViewById(R.id.nameEditText);
        emaiEditText = findViewById(R.id.emailEditText);
        idEditText = findViewById(R.id.idEditText);
        deptTextView =findViewById(R.id.deptValue);
		
		//Added Newly
		findViewById(R.id.departmentSelect).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, DepartmentActivity.class);
                startActivityForResult(intent, REQ_CODE);
            }
        });


        findViewById(R.id.submit).setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {

                String errMsg = "";
                String name = nameEditText.getText().toString();
                String idval = idEditText.getText().toString();
                String email = emaiEditText.getText().toString();
                String dept = deptTextView.getText().toString();

                if (name.isEmpty()) {
                    errMsg = errMsg + getString(R.string.error_msg_name_empty);
                } else if (!name.matches(namePattern)) {
                    errMsg = errMsg + getString(R.string.error_msg_invalid_name);
                }errMsg = errMsg + " ";

                if (email.isEmpty()) {
                    errMsg = errMsg + getString(R.string.error_msg_email_empty);
                } else if (!email.trim().matches(emailPattern)) {
                    errMsg = errMsg + getString(R.string.error_msg_email);
                }errMsg = errMsg + " ";

                if (idval.isEmpty()) {
                    errMsg = errMsg + getString(R.string.error_msg_id_empty) + " ";
                }
                if (dept.isEmpty()) {
                    errMsg = errMsg + getString(R.string.error_msg_dept_empty) + " ";
                }

                if (errMsg != null && !errMsg.isEmpty()) {
                    Toast.makeText(MainActivity.this, errMsg, Toast.LENGTH_SHORT).show();
                } else {

                    // go to profile page
                    Student stud = new Student();
                    stud.name = name;
                    stud.emailID = email;
                    stud.studID = idval;
                    stud.department = dept;

                    Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
                    intent.putExtra(PROFILE_KEY, stud);
                    startActivity(intent);
                }
            }
        });
		setTitle(getString(R.string.app_name));
    }

	public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

            if (resultCode == RESULT_OK) {
                if (data != null && data.hasExtra(DepartmentActivity.deptVal)){
                    String str = data.getStringExtra(DepartmentActivity.deptVal);
                    deptTextView.setText(str);
                }
            }
    }
}
