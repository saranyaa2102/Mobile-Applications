package com.example.hw03;

//Saranyaa Thirumoorthy
//KamalaPriya Srinivasan
//Home Work 03
//Group10B

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class Login extends Fragment{
    Button login;
    String Login;
    DataServices.Account User;
    TextView Account;
    EditText Email;
    EditText Password;
    boolean gettingData = false;
    private loginInterface loginIntermediate;
    OnBackPressedCallback goBack;


    public Login() {
    }

    public static Login newInstance() {
        Login fragment = new Login();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.login, container, false);

        Account = view.findViewById(R.id.Register);
        Email = view.findViewById(R.id.Email);
        Password = view.findViewById(R.id.Password);
        login = view.findViewById(R.id.Login);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String loginEmail = Email.getText().toString();
                String loginPassword = Password.getText().toString();
                try {
                    if ((loginEmail.isEmpty())&&(loginPassword.isEmpty())){
                        throw new Exception(getString(R.string.loginDetails));
                    }else if (loginEmail.isEmpty()) {
                        throw new Exception(getString(R.string.incorrectEmail));
                    }else if (loginPassword.isEmpty()) {
                        throw new Exception(getString(R.string.incorrectPassword));
                    }

                    new LoginAsyncTask().execute(new String[]{loginEmail, loginPassword});

                } catch (Exception e) {
                    Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });

        Account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginIntermediate.Create();
            }
        });




        goBack = new OnBackPressedCallback(false) {
            @Override
            public void handleOnBackPressed() {
                if (!gettingData){
                    getActivity().onBackPressed();
                } else {
                    Toast.makeText(getActivity(), getString(R.string.gettingData), Toast.LENGTH_SHORT).show();
                }
            }
        };
        getActivity().getOnBackPressedDispatcher().addCallback(goBack);
        goBack.setEnabled(false);
        return view;
    }

    private void updateVisibility(boolean isVisibile) {
        if (isVisibile){
            login.setEnabled(true);
            Account.setVisibility(View.VISIBLE);
        } else {
            login.setEnabled(false);
            Account.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public void onAttach(@NonNull Context context) {
        if (context instanceof loginInterface) {
            loginIntermediate = (loginInterface) context;
        }
        super.onAttach(context);
    }


    public interface loginInterface {
        void Login(String loginToken, DataServices.Account account);
        void Create();
    }

    class LoginAsyncTask extends AsyncTask<String[], String, DataServices.Account> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            updateVisibility(false);
            gettingData = true;
            goBack.setEnabled(true);
        }

        @Override
        protected void onProgressUpdate(String... values) {
            Toast.makeText(getActivity(), values[0], Toast.LENGTH_SHORT).show();
        }

        @Override
        protected DataServices.Account doInBackground(String[]... strings) {
            DataServices.Account accountFetched = null;
            try {
                Login = DataServices.login(strings[0][0], strings[0][1]);
                accountFetched = DataServices.getAccount(Login);
                if (accountFetched != null){
                    publishProgress(getResources().getString(R.string.login));
                }
            } catch (DataServices.RequestException e) {
                publishProgress(e.getMessage());
            }
            return accountFetched;
        }

        @Override
        protected void onPostExecute(DataServices.Account accountFetched) {
            super.onPostExecute(accountFetched);
            updateVisibility(true);
            User = accountFetched;
            gettingData = false;
            if(User != null){
                goBack.setEnabled(false);
                loginIntermediate.Login(Login, User);
            }

        }
    }
}
