package com.example.hw03;

//Group10B
//Saranyaa Thirumoorthy
//KamalaPriya Srinivasan
//Home Work 03

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;



public class Register extends Fragment {
    TextView Cancel;
    Button submit;
    OnBackPressedCallback goBack;
    boolean Processing = false;
    TextView name;
    TextView email;
    TextView password;

    String registerDetails;
    DataServices.Account account;

    private registerInterface register;

    public Register() {

    }

    public static Register newInstance() {
        Register fragment = new Register();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.register, container, false);

        submit = view.findViewById(R.id.Submit);
        Cancel = view.findViewById(R.id.CancelButton);

        name = view.findViewById(R.id.newName);
        email = view.findViewById(R.id.NewEmail);
        password = view.findViewById(R.id.NewPassword);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String registerName = name.getText().toString();
                String registerEmail = email.getText().toString();
                String registerPassword = password.getText().toString();
                try {
                    if (registerName.isEmpty() && registerEmail.isEmpty() && registerPassword.isEmpty() ){
                        throw new Exception(getString(R.string.reg));
                    }else if (registerName.isEmpty()) {
                        throw new Exception(getString(R.string.incorrectName));
                    }else if (registerEmail.isEmpty()) {
                        throw new Exception(getString(R.string.incorrectEmail));
                    }else if (registerPassword.isEmpty()) {
                        throw new Exception(getString(R.string.incorrectPassword));
                    }

                    new RegisterAsyncTask().execute(new String[]{registerName, registerEmail, registerPassword});
                } catch (Exception e) {
                    Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });

        Cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), getString(R.string.cancelled_registration), Toast.LENGTH_SHORT).show();
                register.Cancel();
            }
        });

        goBack = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (Processing) {
                    Toast.makeText(getActivity(), getString(R.string.gettingData), Toast.LENGTH_SHORT).show();
                } else {
                    getActivity().onBackPressed();
                }
            }
        };
        getActivity().getOnBackPressedDispatcher().addCallback(goBack);
        goBack.setEnabled(false);
        return view;
    }



    private void updateVisibility(boolean isVisibile) {
        if (isVisibile) {
            submit.setEnabled(true);
            Cancel.setVisibility(View.VISIBLE);
        } else {
            submit.setEnabled(false);
            Cancel.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public void onAttach(@NonNull Context context) {
        if (context instanceof registerInterface) {
            register = (registerInterface) context;
        }
        super.onAttach(context);
    }


    public interface registerInterface {
        void Submit(String token, DataServices.Account account);

        void Cancel();
    }

    class RegisterAsyncTask extends AsyncTask<String[], String, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Processing = true;
            goBack.setEnabled(Processing);
            updateVisibility(false);
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            Toast.makeText(getActivity(), values[0], Toast.LENGTH_SHORT).show();
        }

        @Override
        protected String doInBackground(String[]... strings) {
            try {
                publishProgress(getResources().getString(R.string.registering));
                registerDetails = DataServices.register(strings[0][0], strings[0][1], strings[0][2]);
                publishProgress(getResources().getString(R.string.register));
                if (registerDetails != null) {
                    publishProgress(getResources().getString(R.string.gettingData));
                    account = DataServices.getAccount(registerDetails);
                }
            } catch (DataServices.RequestException e) {
                publishProgress(e.getMessage());
            }
            return registerDetails;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Processing = false;
            goBack.setEnabled(Processing);
            updateVisibility(true);
            register.Submit(registerDetails, account);
        }
    }
}
