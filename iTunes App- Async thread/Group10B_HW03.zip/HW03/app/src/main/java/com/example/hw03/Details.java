package com.example.hw03;
//Saranyaa Thirumoorthy
//KamalaPriya Srinivasan
//Home Work 03
//Group10B




import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


public class Details extends Fragment{
    private static final String DETAILS = "DETAILS";
    private DataServices.App iTunes;
    TextView Name;
    TextView artist;
    TextView Date;
    RecyclerView View;
    DetailsAdapter adapter;
    LinearLayoutManager Layout;
    String[] genres;

    public Details() {

    }

    public static Details newInstance(DataServices.App iTunes) {
        Details fragment = new Details();
        Bundle args = new Bundle();
        args.putSerializable(DETAILS, iTunes);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            iTunes = (DataServices.App) getArguments().getSerializable(DETAILS);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.details, container, false);
        Name = view.findViewById(R.id.DetailsName);
        artist = view.findViewById(R.id.DetailsArtistName);
        Date = view.findViewById(R.id.DetailsDate);


        View = view.findViewById(R.id.DetailsView);

        genres = iTunes.genres.toArray(new String[iTunes.genres.size()]);

        Name.setText(iTunes.name);
        artist.setText(iTunes.artistName);
        Date.setText(iTunes.releaseDate);

        Layout = new LinearLayoutManager(getContext());
        adapter = new DetailsAdapter(genres);
        View.setLayoutManager(Layout);
        View.setAdapter(adapter);

        return view;
    }

}
