package com.example.hw03;

//Saranyaa Thirumoorthy
//KamalaPriya Srinivasan
//Home Work 03
//MainActivity.java


import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity
        implements List.listinterface, Login.loginInterface,
        Categories.categoriesInterface, Register.registerInterface {

    DataServices.Account userAccount;
    String loginDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportFragmentManager().beginTransaction()
                .add(R.id.rootView, Login.newInstance())
                .commit();
        setTitle(R.string.LoginPage);
    }

    @Override
    public void Login(String loginDetails, DataServices.Account userAccount) {
        this.loginDetails = loginDetails;
        this.userAccount = userAccount;
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, Categories.newInstance(loginDetails, userAccount))
                .commit();
        setTitle(R.string.appCategoriesPage);
    }

    @Override
    public void onClickHandler(int position, String[] categories) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, List.newInstance(loginDetails, categories[position]))
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void Create() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, Register.newInstance())
                .commit();
        setTitle(R.string.RegistrationPage);
    }


    @Override
    public void Submit(String token, DataServices.Account userAccount) {
        this.loginDetails = token;
        this.userAccount = userAccount;
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, Categories.newInstance(token, userAccount))
                .commit();
    }

    @Override
    public void Logout() {
        userAccount = null;
        loginDetails = null;
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, Login.newInstance())
                .commit();
        setTitle(R.string.LoginPage);
    }

    @Override
    public void Cancel() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, Login.newInstance())
                .commit();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public void onAppListClickHandler(DataServices.App app) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, Details.newInstance(app))
                .addToBackStack(null)
                .commit();
        setTitle(R.string.appDetailsPage);
    }
}