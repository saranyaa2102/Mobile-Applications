package com.example.hw03;

//Saranyaa Thirumoorthy
//KamalaPriya Srinivasan
//Home Work 03
//Group10B

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class ItemAdapter extends ArrayAdapter<DataServices.App>{

    public ItemAdapter(@NonNull Context context, int resource, @NonNull List<DataServices.App> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int place, @Nullable View convertView, @NonNull ViewGroup parent) {

        if (convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.details,parent,false);
        }
        DataServices.App iTunes = getItem(place);
        TextView Name = convertView.findViewById(R.id.Name);
        TextView artist = convertView.findViewById(R.id.artist);
        TextView Date = convertView.findViewById(R.id.Date);
        Name.setText(iTunes.name);
        artist.setText(iTunes.artistName);
        Date.setText(iTunes.releaseDate);

        return convertView;
    }
}
