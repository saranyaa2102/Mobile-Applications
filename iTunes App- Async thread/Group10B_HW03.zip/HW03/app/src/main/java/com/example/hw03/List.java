package com.example.hw03;

//Saranyaa Thirumoorthy
//KamalaPriya Srinivasan
//Home Work 03
//Group10B


import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class List extends Fragment {

    private static final String LOGIN = "LOGIN";
    private static final String CATEGORY = "CATEGORY";
    private String login;
    private String category;
    TextView appName;
    TextView artistName;
    TextView releaseDate;
    OnBackPressedCallback goBack;
    boolean Processing = false;
    LinearLayoutManager Layout;
    RecyclerView View;
    ListAdapter adapter;
    ArrayList<DataServices.App> apps = new ArrayList<>();
    listinterface listener;

    public List() {

    }

    public static List newInstance(String loginToken, String categoryName) {
        List fragment = new List();
        Bundle args = new Bundle();
        args.putString(LOGIN, loginToken);
        args.putString(CATEGORY, categoryName);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            login = getArguments().getString(LOGIN);
            category = getArguments().getString(CATEGORY);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.list, container, false);

        getActivity().setTitle(category);

        appName = view.findViewById(R.id.DetailsName);
        artistName = view.findViewById(R.id.DetailsArtistName);
        releaseDate = view.findViewById(R.id.DetailsDate);

        Layout = new LinearLayoutManager(getActivity());
        View = view.findViewById(R.id.listsOfApps);
        View.setLayoutManager(Layout);

        goBack = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (Processing) {
                    Toast.makeText(getActivity(), getString(R.string.appList), Toast.LENGTH_SHORT).show();
                } else {
                    getActivity().onBackPressed();
                }
            }
        };
        getActivity().getOnBackPressedDispatcher().addCallback(goBack);
        goBack.setEnabled(false);

        if (apps.isEmpty()){
            new AppCategoryAsyncTask().execute(new String[]{login, category});
        }
        adapter = new ListAdapter(apps, listener);
        View.setAdapter(adapter);

        return view;
    }


    @Override
    public void onAttach(@NonNull Context context) {
        if (context instanceof listinterface) {
            listener = (listinterface) context;
        }
        super.onAttach(context);
    }


    public interface listinterface {
        void onAppListClickHandler(DataServices.App app);
    }



    class AppCategoryAsyncTask extends AsyncTask<String[], String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Processing = true;
            goBack.setEnabled(Processing);
        }

        @Override
        protected void onProgressUpdate(String... strings) {
            Toast.makeText(getActivity(), strings[0], Toast.LENGTH_SHORT).show();
            adapter = new ListAdapter(apps, listener);
            View.setAdapter(adapter);
        }

        @Override
        protected String doInBackground(String[]... strings) {
            try {
                publishProgress(getResources().getString(R.string.appList));
                apps = DataServices.getAppsByCategory(strings[0][0], strings[0][1]);

                if(getContext() != null && getResources() != null){
                    publishProgress(getResources().getString(R.string.appList_Fetched));
                }

            } catch (DataServices.RequestException e) {
                publishProgress(e.getMessage());
            }
            return login;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Processing = false;
            goBack.setEnabled(Processing);
        }
    }
}
