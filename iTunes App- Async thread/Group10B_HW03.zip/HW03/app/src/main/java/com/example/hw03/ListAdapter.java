package com.example.hw03;


//Saranyaa Thirumoorthy
//KamalaPriya Srinivasan
//Home Work 03
//Group10B

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;


public class ListAdapter extends RecyclerView.Adapter<ListAdapter.AppListViewHolder>{
    private ArrayList<DataServices.App> iTunes;
    private List.listinterface List;

    public ListAdapter(ArrayList<DataServices.App> apps, List.listinterface appListListener) {
        this.iTunes = apps;
        this.List = appListListener;
    }

    @NonNull
    @Override
    public AppListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.details_adapter, parent, false);
        AppListViewHolder View = new AppListViewHolder(view);
        return View;
    }

    @Override
    public void onBindViewHolder(@NonNull AppListViewHolder holder, int position) {
        DataServices.App app = iTunes.get(position);
        holder.Name.setText(app.name);
        holder.artist.setText(app.artistName);
        holder.Date.setText(app.releaseDate);
        holder.iTunes = app;
        holder.appListListener = List;
    }

    @Override
    public int getItemCount() {
        return this.iTunes != null ? this.iTunes.size() : 0;
    }

    public static class AppListViewHolder extends RecyclerView.ViewHolder {
        private TextView Name;
        private TextView artist;
        private TextView Date;
        private DataServices.App iTunes;
        private List.listinterface appListListener;


        public AppListViewHolder(@NonNull View itemView) {
            super(itemView);

            Name = itemView.findViewById(R.id.Name);
            artist = itemView.findViewById(R.id.artist);
            Date = itemView.findViewById(R.id.Date);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    appListListener.onAppListClickHandler(iTunes);
                }
            });
        }
    }

}
