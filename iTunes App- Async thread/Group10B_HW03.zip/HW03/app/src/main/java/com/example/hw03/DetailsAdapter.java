package com.example.hw03;

//Saranyaa Thirumoorthy
//KamalaPriya Srinivasan
//Home Work 03
//Group10B

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class DetailsAdapter extends RecyclerView.Adapter<DetailsAdapter.AppDetailsViewHolder> {
    private String[] genres;
    public DetailsAdapter(String[] genres) {
        this.genres = genres;
    }
    @NonNull
    @Override
    public AppDetailsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view =
                LayoutInflater.from(parent.getContext())
                        .inflate(android.R.layout.simple_list_item_1, parent, false);
        AppDetailsViewHolder View = new AppDetailsViewHolder(view);
        return View;
    }
    @Override
    public void onBindViewHolder(@NonNull AppDetailsViewHolder holder, int place) {
        holder.tView.setText(genres[place]);
    }
    @Override
    public int getItemCount() {
        return this.genres != null ? this.genres.length : 0;
    }

    public static class AppDetailsViewHolder extends RecyclerView.ViewHolder {
        private TextView tView;
        public AppDetailsViewHolder(@NonNull View itemView) {
            super(itemView);
            tView = itemView.findViewById(android.R.id.text1);
        }
    }
}
