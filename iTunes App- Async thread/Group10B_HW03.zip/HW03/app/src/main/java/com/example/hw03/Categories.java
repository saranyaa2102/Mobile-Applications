package com.example.hw03;


//Saranyaa Thirumoorthy
//KamalaPriya Srinivasan
//Home Work 03
//Group10B


import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class Categories extends Fragment{
    private static final String LOGIN = "LOGIN";
    private static final String ACCOUNT = "ACCOUNT";

    OnBackPressedCallback goback;
    boolean Processing = false;
    TextView greeting;
    Button logout;
    RecyclerView View;
    private String login;
    private DataServices.Account userAccount;
    private String[] categories = new String[]{};
    LinearLayoutManager layout;
    categoriesInterface Categories;
    CategoriesAdapter categoriesadapter;


    public Categories() {

    }

    public static Categories newInstance(String loginToken, DataServices.Account userAccount) {
        Categories fragment = new Categories();
        Bundle args = new Bundle();
        args.putString(LOGIN, loginToken);
        args.putSerializable(ACCOUNT, userAccount);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            login = getArguments().getString(LOGIN);
            userAccount = (DataServices.Account) getArguments().getSerializable(ACCOUNT);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.categories, container, false);
        greeting = view.findViewById(R.id.greetings);
        logout = view.findViewById(R.id.logOut);

        View = view.findViewById(R.id.categories);
        layout = new LinearLayoutManager(getContext());
        View.setLayoutManager(layout);

        greeting.setText(getString(R.string.welcome) + " " + userAccount.getName());

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), getString(R.string.logout), Toast.LENGTH_SHORT).show();
                Categories.Logout();
            }
        });

        goback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (Processing) {
                    Toast.makeText(getActivity(), getString(R.string.gettingData), Toast.LENGTH_SHORT).show();
                } else {
                    getActivity().onBackPressed();
                }
            }
        };
        getActivity().getOnBackPressedDispatcher().addCallback(goback);
        goback.setEnabled(false);

        if (categories.length == 0){
            new AppCategoriesAsyncTask().execute(login);
        }
        categoriesadapter = new CategoriesAdapter(Categories, categories);
        View.setAdapter(categoriesadapter);

        return view;
    }


    @Override
    public void onAttach(@NonNull Context context) {
        if (context instanceof categoriesInterface) {
            Categories = (categoriesInterface) context;
        }
        super.onAttach(context);
    }

    public interface categoriesInterface {
        void Logout();
        void onClickHandler(int position, String[] categories);
    }


    class AppCategoriesAsyncTask extends AsyncTask<String, String, String[]> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            logout.setEnabled(false);
            Processing = true;
            goback.setEnabled(Processing);
        }

        @Override
        protected void onProgressUpdate(String... strings) {
            Toast.makeText(getActivity(), strings[0], Toast.LENGTH_SHORT).show();
            categoriesadapter = new CategoriesAdapter(Categories, categories);
            View.setAdapter(categoriesadapter);
            if (!strings[0].equalsIgnoreCase(getResources().getString(R.string.categories))) {
                logout.setEnabled(true);
            }
        }

        @Override
        protected String[] doInBackground(String... strings) {
            try {
                publishProgress(getResources().getString(R.string.categories));
                ArrayList<String> data = DataServices.getAppCategories(strings[0]);
                categories = data.toArray(new String[data.size()]);
                publishProgress(getResources().getString(R.string.gotCategories));
            } catch (DataServices.RequestException e) {
                publishProgress(e.getMessage());
            }
            return categories;
        }

        @Override
        protected void onPostExecute(String[] strings) {
            super.onPostExecute(strings);
            Processing = false;
            goback.setEnabled(Processing);
            logout.setEnabled(true);
        }
    }

}
