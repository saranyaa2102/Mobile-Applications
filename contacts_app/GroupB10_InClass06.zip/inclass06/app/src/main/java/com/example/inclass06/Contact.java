//Inclass 06
//Saranyaa Thirumoorthy
//Kamalapriya Srinivasan
//Group B10
//Contact.java

package com.example.inclass06;

import java.io.Serializable;

public class Contact implements Serializable {

    String  name, email, phone, type;
    int id = 0;
    public Contact(String name, String email, String phone, String type) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.type = type;
    }

    public Contact() {
    }

    public Contact(String numline) {
        String[] tempContact = numline.split(",");
        this.id = Integer.valueOf(tempContact[0]);
        this.name = tempContact[1];
        this.email = tempContact[2];
        this.phone = tempContact[3];
        this.type = tempContact[4];
    }

    @Override
    public String toString() {
        return "Contact{" +
                "name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                ", type='" + type + '\'' +
                ", id=" + id +
                '}';
    }
}
