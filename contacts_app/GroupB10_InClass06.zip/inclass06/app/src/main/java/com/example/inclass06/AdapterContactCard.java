//Inclass 06
//Saranyaa Thirumoorthy
//Kamalapriya Srinivasan
//Group B10
//AdapterContactCard.java

package com.example.inclass06;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;

import java.util.ArrayList;

import okhttp3.OkHttpClient;

public class AdapterContactCard extends ArrayAdapter<Contact> {

    ArrayList<Contact> listOfContacts;
    private static final String TAG = "TAG";
    OkHttpClient client = new OkHttpClient();
    adapterInterface ai;

    public AdapterContactCard(@NonNull Context context, int resource, @NonNull ArrayList<Contact> objects, adapterInterface ai) {
        super(context, resource, objects);
        this.listOfContacts = objects;
        this.ai = ai;
    }


    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder holder;
        if(convertView == null){
            LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.layout_contact_card,parent,false);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else{
            holder = (ViewHolder) convertView.getTag();
        }

        final Contact contactCurrent = getItem(position);
        holder.nameContact.setText(contactCurrent.name);
        holder.deleteButton.setOnClickListener (new View.OnClickListener () {; @Override public void onClick (View v) {
            //Toast.makeText (getContext(), allContacts.get (position)+ " Removed", Toast.LENGTH_LONG).show ();
            ai.notifyCustomScenario (contactCurrent);
        } });
        holder.cardContactView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                ai.goToDetailsScenario (contactCurrent);
            }
        });
        return convertView;
    }

    @Override
    public int getCount() {
        return listOfContacts.size();
    }

    static class ViewHolder{
        TextView nameContact;
        Button deleteButton;
        CardView cardContactView;
        ViewHolder(View view){
            nameContact = view.findViewById(R.id.nameContactID );
            deleteButton = view.findViewById(R.id.buttonDelete );
            cardContactView = view.findViewById(R.id.cardContactID );
        }

    }



    public interface adapterInterface{
        void goToDetailsScenario(Contact contact);
        void notifyCustomScenario(Contact contact);
    }
}
