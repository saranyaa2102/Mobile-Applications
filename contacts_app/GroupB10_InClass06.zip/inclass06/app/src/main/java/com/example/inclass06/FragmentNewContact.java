//Inclass 06
//Saranyaa Thirumoorthy
//Kamalapriya Srinivasan
//Group B10
//FragmentNewContact.java

package com.example.inclass06;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FragmentNewContact#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FragmentNewContact extends Fragment implements View.OnClickListener {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    OkHttpClient okHttpClient=new OkHttpClient (  );
    EditText nameContact,emailContact,phoneContact,typeContact;
    Button submitButton, cancelButton;
    AlertDialog.Builder builder;
    fragmentNewContactInterface fnci;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public FragmentNewContact() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment FragmentNewContact.
     */
    // TODO: Rename and change types and number of parameters
    public static FragmentNewContact newInstance(String param1 , String param2) {
        FragmentNewContact fragment = new FragmentNewContact ( );
        Bundle args = new Bundle ( );
        args.putString ( ARG_PARAM1 , param1 );
        args.putString ( ARG_PARAM2 , param2 );
        fragment.setArguments ( args );
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        builder = new AlertDialog.Builder(getActivity());
        if (getArguments ( ) != null) {
            mParam1 = getArguments ( ).getString ( ARG_PARAM1 );
            mParam2 = getArguments ( ).getString ( ARG_PARAM2 );
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater , ViewGroup container ,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate ( R.layout.fragment_new_contact , container , false );
        nameContact = v.findViewById(R.id.nameNewContact);
        emailContact = v.findViewById(R.id.emailNewContact);
        phoneContact = v.findViewById(R.id.phoneNewContact);
        typeContact = v.findViewById(R.id.typeNewContact);
        submitButton = v.findViewById(R.id.submitButton);
        cancelButton = v.findViewById(R.id.cancelButton);
        submitButton.setOnClickListener(this);
        cancelButton.setOnClickListener(this);
        return v;
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.submitButton:
                String createdName = nameContact.getText().toString();
                String createdEmail = emailContact.getText().toString();
                String createdPhone = phoneContact.getText().toString();
                String createdType = typeContact.getText().toString();

                if ((createdName.isEmpty()) && (createdEmail.isEmpty()) && (createdPhone.isEmpty()) && (createdType.isEmpty())) {
                    builder.setTitle("Empty Fields Alert!");
                    builder.setMessage("Please Enter Name,Email,Phone number and Type to create a contact");
                    AlertDialog alert = builder.create();
                    alert.show();

                } else if (createdName.isEmpty()){
                    builder.setTitle("Empty Fields Alert!");
                    builder.setMessage("Please Enter Name");
                    AlertDialog alert = builder.create();
                    alert.show();
                } else if (createdEmail.isEmpty()){
                    builder.setTitle("Empty Fields Alert!");
                    builder.setMessage("Please Enter Email");
                    AlertDialog alert = builder.create();
                    alert.show();
                } else if (createdPhone.isEmpty()) {
                    builder.setTitle("Empty Fields Alert!");
                    builder.setMessage("Please Enter Phone");
                    AlertDialog alert = builder.create();
                    alert.show();
                }else if (createdType.isEmpty()){
                    builder.setTitle("Empty Fields Alert!");
                    builder.setMessage("Please Enter Type");
                    AlertDialog alert = builder.create();
                    alert.show();
                } else{
                    createContact(createdName,createdEmail,createdPhone,createdType);
                }

                break;
            case R.id.cancelButton:
                fnci.goToPopBackScenario ();
                break;
        }
    }

    public void createContact(String newName, String newEmail, String newPhone, String newType){
        FormBody formBody = new FormBody.Builder()
                .add("name",newName)
                .add("email",newEmail)
                .add("phone",newPhone)
                .add("type",newType)
                .build();


        Request request = new Request.Builder()
                .url("https://www.theappsdr.com/contact/create")
                .post(formBody)
                .build();

        okHttpClient.newCall(request).enqueue(new Callback () {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                System.out.println (e );
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                final String resbody = response.body().string();
                if(!response.isSuccessful()){
                    System.out.println (resbody );
                }
                if(response.isSuccessful() ){
                    System.out.println (resbody );
                    fnci.goToContactsListScenario ();
                }

                if(!response.isSuccessful()){
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //Toast.makeText(getContext(), resbody, Toast.LENGTH_SHORT).show();
                        }
                    });
                }

            }
        });
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if(context instanceof FragmentNewContact.fragmentNewContactInterface){
            fnci = (FragmentNewContact.fragmentNewContactInterface) context;
        }else{
            throw new RuntimeException(context.toString());
        }
    }

    public interface fragmentNewContactInterface{
        void goToContactsListScenario();
        void goToPopBackScenario();
    }
}