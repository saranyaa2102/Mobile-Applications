//Inclass 06
//Saranyaa Thirumoorthy
//Kamalapriya Srinivasan
//Group B10
//MainActivity.java

package com.example.inclass06;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.util.ArrayList;

import okhttp3.OkHttpClient;
public class MainActivity extends AppCompatActivity implements FragmentListContacts.fragmentContactListingInterface,FragmentNewContact.fragmentNewContactInterface,FragmentEditContact.fragmentEditContactInterface,FragmentContactDetails.fragmentContactDetailsInterface {


    public static ArrayList<Contact> listOfContacts=new ArrayList<> (  );
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_main );
        listOfContacts = new ArrayList<>();
        getSupportFragmentManager().beginTransaction().add(R.id.fragmentID,new FragmentListContacts ()).commit();
    }

    @Override
    public void goToContactDetailsScenario(Contact contact) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentID,new FragmentContactDetails (contact)).addToBackStack(null).commit();
    }

    @Override
    public void addAContactScenario() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentID, new FragmentNewContact ()).addToBackStack(null).commit();
    }

    @Override
    public void goToEditContactScenario(Contact contact) {
        getSupportFragmentManager().beginTransaction().replace(R.id.fragmentID,new FragmentEditContact (contact))
                .addToBackStack(null).commit();
    }

    @Override
    public void goToContactsListScenario() {
        getSupportFragmentManager().beginTransaction().replace(R.id.fragmentID, new FragmentListContacts ()).commit();
    }


    @Override
    public void goToPopBackScenario() {
        getSupportFragmentManager().popBackStack();
    }



}