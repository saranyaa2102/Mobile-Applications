//Inclass 06
//Saranyaa Thirumoorthy
//Kamalapriya Srinivasan
//Group B10
//FragmentContactDetails.java

package com.example.inclass06;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.ArrayList;


import okhttp3.OkHttpClient;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.Request;
import okhttp3.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FragmentContactDetails#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FragmentContactDetails extends Fragment implements View.OnClickListener {


    Contact contactCurrent;
    TextView name,email,phone,type;
    Button edit,delete;
    fragmentContactDetailsInterface fcdi;
    OkHttpClient okHttpClient=new OkHttpClient (  );

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public FragmentContactDetails() {
        // Required empty public constructor
    }
    public FragmentContactDetails(Contact contact){
        this.contactCurrent = contact;
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment FragmentContactDetails.
     */
    // TODO: Rename and change types and number of parameters
    public static FragmentContactDetails newInstance(String param1 , String param2) {
        FragmentContactDetails fragment = new FragmentContactDetails ( );
        Bundle args = new Bundle ( );
        args.putString ( ARG_PARAM1 , param1 );
        args.putString ( ARG_PARAM2 , param2 );
        fragment.setArguments ( args );
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        if (getArguments ( ) != null) {
            mParam1 = getArguments ( ).getString ( ARG_PARAM1 );
            mParam2 = getArguments ( ).getString ( ARG_PARAM2 );
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater , ViewGroup container ,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate ( R.layout.fragment_contact_details , container , false );
        name = v.findViewById(R.id.nameContactID);
        email = v.findViewById(R.id.emailContact);
        phone = v.findViewById(R.id.phoneContact);
        type = v.findViewById(R.id.typeContact);
        edit = v.findViewById(R.id.buttonEditContact);
        delete = v.findViewById(R.id.buttonDeletecontact);

        name.setText(contactCurrent.name);
        email.setText(contactCurrent.email);
        phone.setText(contactCurrent.phone);
        type.setText(contactCurrent.type);

        edit.setOnClickListener(this);
        delete.setOnClickListener(this);
        return v;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonEditContact:
                fcdi.goToEditContactScenario (contactCurrent);
                break;
            case R.id.buttonDeletecontact:
                String id = String.valueOf(contactCurrent.id);
                FormBody formBody = new FormBody.Builder()
                        .add("id",id)
                        .build();

                Request request = new Request.Builder()
                        .url("https://www.theappsdr.com/contact/delete")
                        .post(formBody)
                        .build();
                okHttpClient.newCall(request).enqueue(new Callback () {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        System.out.println (e );
                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        if(!response.isSuccessful()) throw new IOException("delete callback not successful");
                        fcdi.goToContactsListScenario ();
                    }
                });

                break;
        }
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if(context instanceof FragmentContactDetails.fragmentContactDetailsInterface){
            fcdi = (FragmentContactDetails.fragmentContactDetailsInterface)context;
        }else{
            throw new RuntimeException(context.toString());
        }
    }

    public interface fragmentContactDetailsInterface{
        void goToEditContactScenario(Contact contact);
        void goToContactsListScenario();

    }
}