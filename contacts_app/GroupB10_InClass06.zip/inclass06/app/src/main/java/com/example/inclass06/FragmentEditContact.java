//Inclass 06
//Saranyaa Thirumoorthy
//Kamalapriya Srinivasan
//Group B10
//FragmentNewContact.java

package com.example.inclass06;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FragmentEditContact#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FragmentEditContact extends Fragment implements View.OnClickListener{

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    OkHttpClient okHttpClient=new OkHttpClient (  );
    Contact contactCurrent;
    fragmentEditContactInterface feci;
    EditText nameContact,emailContact,phoneContact,typeContact;
    Button updateButton,backButton;
    AlertDialog.Builder builder;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public FragmentEditContact() {
        // Required empty public constructor
    }
    public FragmentEditContact(Contact contactCurrent){
        this.contactCurrent = contactCurrent;

    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment FragmentEditContact.
     */
    // TODO: Rename and change types and number of parameters
    public static FragmentEditContact newInstance(String param1 , String param2) {
        FragmentEditContact fragment = new FragmentEditContact ( );
        Bundle args = new Bundle ( );
        args.putString ( ARG_PARAM1 , param1 );
        args.putString ( ARG_PARAM2 , param2 );
        fragment.setArguments ( args );
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        builder = new AlertDialog.Builder(getActivity());
        if (getArguments ( ) != null) {
            mParam1 = getArguments ( ).getString ( ARG_PARAM1 );
            mParam2 = getArguments ( ).getString ( ARG_PARAM2 );
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater , ViewGroup container ,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate ( R.layout.fragment_edit_contact , container , false );
        nameContact = v.findViewById(R.id.nameEditcon);
        emailContact  =v.findViewById(R.id.emailEditCon);
        phoneContact = v.findViewById(R.id.phoneEditCon);
        typeContact = v.findViewById(R.id.typeEditCon);

        updateButton = v.findViewById(R.id.buttonUpdate);
        backButton = v.findViewById(R.id.buttonBack);
        nameContact.setText(contactCurrent.name);
        emailContact.setText(contactCurrent.email);
        phoneContact.setText(contactCurrent.phone);
        typeContact.setText(contactCurrent.type);

        updateButton.setOnClickListener( this );
        backButton.setOnClickListener(  this );
        return v;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonUpdate:
                String id = String.valueOf(contactCurrent.id);
                String updatedName = nameContact.getText().toString();
                String updatedEmail = emailContact.getText().toString();
                String updatedPhone = phoneContact.getText().toString();
                String updatedType = typeContact.getText().toString();
                FormBody formBody = new FormBody.Builder()
                        .add("id",id)
                        .add("name",updatedName)
                        .add("email",updatedEmail)
                        .add("phone",updatedPhone)
                        .add("type",updatedType)
                        .build();
                if ((updatedName.isEmpty()) && (updatedEmail.isEmpty()) && (updatedPhone.isEmpty()) && (updatedType.isEmpty())) {
                    builder.setTitle("Empty Fields Alert!");
                    builder.setMessage("Please Enter Name,Email,Phone number and Type to create a contact");
                    AlertDialog alert = builder.create();
                    alert.show();

                } else if (updatedName.isEmpty()){
                    builder.setTitle("Empty Fields Alert!");
                    builder.setMessage("Please Enter Name");
                    AlertDialog alert = builder.create();
                    alert.show();
                } else if (updatedEmail.isEmpty()){
                    builder.setTitle("Empty Fields Alert!");
                    builder.setMessage("Please Enter Email");
                    AlertDialog alert = builder.create();
                    alert.show();
                } else if (updatedPhone.isEmpty()) {
                    builder.setTitle("Empty Fields Alert!");
                    builder.setMessage("Please Enter Phone");
                    AlertDialog alert = builder.create();
                    alert.show();
                }else if (updatedType.isEmpty()){
                    builder.setTitle("Empty Fields Alert!");
                    builder.setMessage("Please Enter Type");
                    AlertDialog alert = builder.create();
                    alert.show();
                } else{
                Request request = new Request.Builder()
                        .url("https://www.theappsdr.com/contact/update")
                        .post(formBody)
                        .build();

                okHttpClient.newCall(request).enqueue(new Callback () {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        System.out.println (e );
                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        if(!response.isSuccessful()) System.out.println (response.body().string());

                        if(response.isSuccessful() ){
                            System.out.println (response.body().string());

                        }
                        feci.goToContactsListScenario ();
                    }
                });
                }
                break;
            case R.id.buttonBack:
                feci.goToPopBackScenario ();
                break;
        }
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if(context instanceof FragmentEditContact.fragmentEditContactInterface){
            feci = (FragmentEditContact.fragmentEditContactInterface)context;
        }else{
            throw new RuntimeException(context.toString());
        }
    }


    public interface fragmentEditContactInterface{
        void goToContactsListScenario();
        void goToPopBackScenario();
    }
}