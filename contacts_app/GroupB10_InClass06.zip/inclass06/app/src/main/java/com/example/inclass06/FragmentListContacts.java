//Inclass 06
//Saranyaa Thirumoorthy
//Kamalapriya Srinivasan
//Group B10
//FragmentListContacts.java

package com.example.inclass06;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.ArrayList;


import okhttp3.OkHttpClient;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.Request;
import okhttp3.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FragmentListContacts#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FragmentListContacts extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    static OkHttpClient okHttpClient=new OkHttpClient (  );
    fragmentContactListingInterface fcli;
    Button addAContact;
    ListView clv;
    AdapterContactCard adapterContactCard;
    ArrayList<Contact> listOFContacts = new ArrayList<>();
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public FragmentListContacts(ArrayList<Contact> listContacts) {
        // Required empty public constructor
        this.listOFContacts=listContacts;
    }
    public FragmentListContacts(){}


    // TODO: Rename and change types and number of parameters
    public static FragmentListContacts newInstance(ArrayList<Contact> listContacts) {
        FragmentListContacts fragment = new FragmentListContacts(listContacts);
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        if (getArguments ( ) != null) {
            mParam1 = getArguments ( ).getString ( ARG_PARAM1 );
            mParam2 = getArguments ( ).getString ( ARG_PARAM2 );
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater , ViewGroup container ,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        getAllContactsScenario ();
        View v= inflater.inflate ( R.layout.fragment_list_contacts , container , false );
        addAContact=v.findViewById ( R.id.addAContact );
        addAContact.setOnClickListener ( new View.OnClickListener ( ) {
            @Override
            public void onClick(View v) {
                fcli.addAContactScenario ();
            }
        } );

        clv = v.findViewById(R.id.contactsExistingListView);
        clv.setFocusable(false);
        adapterContactCard = new AdapterContactCard (getContext(), R.layout.layout_contact_card, listOFContacts, new AdapterContactCard .adapterInterface () {
            @Override
            public void goToDetailsScenario(Contact contactCurrent) {
                fcli.goToContactDetailsScenario (contactCurrent);
            }

            @Override
            public void notifyCustomScenario(Contact contact) {
                String contactId = String.valueOf(contact.id);
                FormBody formBody = new FormBody.Builder()
                        .add("id",contactId)
                        .build();

                Request request = new Request.Builder()
                        .url("https://www.theappsdr.com/contact/delete")
                        .post(formBody)
                        .build();
                okHttpClient.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        System.out.println (e );
                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        if(!response.isSuccessful()) System.out.println ("Not successful" );;
                        if(response.isSuccessful() ){
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    getAllContactsScenario();
                                    adapterContactCard.notifyDataSetChanged();
                                }
                            });
                        }
                    }
                });
            }

        });
        clv.setAdapter(adapterContactCard);
        return  v;
    }


    public void getAllContactsScenario(){
        Request request = new Request.Builder().url("https://www.theappsdr.com/contacts").build();
        okHttpClient = new OkHttpClient();
        okHttpClient.newCall(request).enqueue(new Callback () {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                System.out.println (e);}

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if(!response.isSuccessful()) throw new IOException("Unexpected Code");
                String body = response.body().string();
                listOFContacts.clear();
                String[] numLines = body.split("\n");
                if(numLines.length>1){
                    for(String numLine: numLines){
                        listOFContacts.add(new Contact(numLine));
                    }
                }

                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        adapterContactCard.notifyDataSetChanged();
                    }
                });
            }
        });


    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if(context instanceof FragmentListContacts.fragmentContactListingInterface){
            fcli = (FragmentListContacts.fragmentContactListingInterface)context;
        }else{
            throw new RuntimeException(context.toString());
        }
    }

    public interface fragmentContactListingInterface{
        void goToContactDetailsScenario(Contact contact);
        void addAContactScenario();
    }
}