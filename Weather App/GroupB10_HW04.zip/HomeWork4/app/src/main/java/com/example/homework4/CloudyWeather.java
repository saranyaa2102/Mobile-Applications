package com.example.homework4;

public class CloudyWeather {
    String cloudyWeather;

    @Override
    public String toString() {
        return "CloudyWeather{" +
                "cloudyWeather='" + cloudyWeather + '\'' +
                '}';
    }

    public String getCloudyWeather() {
        return cloudyWeather;
    }

    public void setCloudyWeather(String cloudyWeather) {
        this.cloudyWeather = cloudyWeather;
    }
}
