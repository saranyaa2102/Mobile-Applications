package com.example.homework4;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.widget.TextView;
import okhttp3.Request;
import okhttp3.Response;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.Toast;
import java.io.IOException;
import java.util.ArrayList;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class Forecast extends Fragment{
    Data.City cityName;
    String key;
    RecyclerView foreCast;
    LinearLayoutManager foreCastLayout;
    TextView weatherValue;
    ForecastAdapter forecastValue;

    private static final String CITYName = "CITY";
    private static final String KEY = "API_ID";


    public Forecast() {
    }


    public static Forecast newInstance(Data.City city, String id) {
        Forecast secondFragment = new Forecast();
        Bundle args = new Bundle();
        args.putSerializable(CITYName, city);
        args.putString(KEY, id);
        secondFragment.setArguments(args);
        return secondFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            cityName = (Data.City) getArguments().getSerializable(CITYName);
            key = getArguments().getString(KEY);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.forecast_list, container, false);
        getActivity().setTitle(getResources().getString(R.string.thirdFragmentTitle));

        weatherValue = view.findViewById(R.id.ForecastedCityName);
        foreCast = view.findViewById(R.id.ForecastDetails);

        foreCast.setHasFixedSize(true);
        foreCastLayout = new LinearLayoutManager(getContext());
        foreCast.setLayoutManager(foreCastLayout);

        new GetWeatherForecastData().execute(cityName.getCity(), cityName.getCountry(), key);

        return view;
    }


    class GetWeatherForecastData extends AsyncTask<String, Integer, ArrayList<ForecastDetails>>{

        final OkHttpClient client = new OkHttpClient();
        String city, country;

        @Override
        protected ArrayList<ForecastDetails> doInBackground(String... strings) {

            city = strings[0];
            country = strings[1];

            HttpUrl url = HttpUrl.parse("https://api.openweathermap.org/data/2.5/forecast").newBuilder()
                    .addQueryParameter("q", strings[0])
                    .addQueryParameter("appid", strings[2])
                    .addQueryParameter("units", "imperial")
                    .build();

            Request request = new Request.Builder()
                    .url(url)
                    .build();

            ArrayList<ForecastDetails> informationList = new ArrayList<>();

            try {
                Response response = client.newCall(request).execute();

                if (response.isSuccessful()){
                    JSONObject obj = new JSONObject(response.body().string());
                    JSONArray fiveDaysForecast = obj.getJSONArray("list");

                    for (int i = 0; i < fiveDaysForecast.length(); i++){

                        ForecastDetails data = new ForecastDetails();
                        weatherTypes weather = new weatherTypes();
                        ArrayList<weatherTypes> weatherList = new ArrayList<>();
                        windyWeather wind = new windyWeather();
                        currentWeatherDetails temperatureInformation = new currentWeatherDetails();
                        CloudyWeather cloud = new CloudyWeather();

                        JSONObject jsonObject = fiveDaysForecast.getJSONObject(i);
                        JSONArray weatherArray = jsonObject.getJSONArray("weather");
                        JSONObject weatherJSONObject = weatherArray.getJSONObject(0);
                        JSONObject mainTempJSONObject = jsonObject.getJSONObject("main");
                        JSONObject windJSONObject = jsonObject.getJSONObject("wind");
                        JSONObject cloudJSONObject = jsonObject.getJSONObject("clouds");

                        weather.setDesc(weatherJSONObject.getString("description"));
                        weather.setClimaticConditionIcon(weatherJSONObject.getString("icon"));
                        weatherList.add(weather);

                        temperatureInformation.setTemperatureFortheDay(mainTempJSONObject.getString("temp"));
                        temperatureInformation.setMaxPredictedTemperatureForTheDay(mainTempJSONObject.getString("temp_max"));
                        temperatureInformation.setMinPredictedTemperatureForTheDay(mainTempJSONObject.getString("temp_min"));
                        temperatureInformation.setHumidityOfTheDay(mainTempJSONObject.getString("humidity"));
                        temperatureInformation.setPressureLevel(mainTempJSONObject.getString("pressure"));

                        wind.setDegree(windJSONObject.getString("deg"));
                        wind.setWindSpeed(windJSONObject.getString("speed"));

                        cloud.setCloudyWeather(cloudJSONObject.getString("all"));

                        data.setPresentWeather(temperatureInformation);
                        data.setWeatherTypes(weatherList);
                        data.setWindCondition(wind);
                        data.setCloudCondition(cloud);
                        data.setDates(jsonObject.getString("dt_txt"));

                        informationList.add(i, data);

                    }
                }
            } catch (IOException | JSONException e) {
                e.printStackTrace();
            }
            return informationList;
        }


        @Override
        protected void onPostExecute(ArrayList<ForecastDetails> totalTemperatureData) {

            if (totalTemperatureData.size() != 0){
                weatherValue.setText(city + ", " + country);
                forecastValue = new ForecastAdapter(totalTemperatureData);
                foreCast.setAdapter(forecastValue);
            }
            else {
                Toast.makeText(getContext(), getResources().getString(R.string.Warning), Toast.LENGTH_SHORT).show();
            }
        }
    }
}
