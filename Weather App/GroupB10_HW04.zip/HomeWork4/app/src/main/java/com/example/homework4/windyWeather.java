package com.example.homework4;

public class windyWeather {
    String windSpeed;
    String degree;

    public String getWindSpeed() {
        return windSpeed;
    }

    public void setWindSpeed(String windSpeed) {
        this.windSpeed = windSpeed;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    @Override
    public String toString() {
        return "windyWeather{" +
                "windSpeed='" + windSpeed + '\'' +
                ", degree='" + degree + '\'' +
                '}';
    }
}
