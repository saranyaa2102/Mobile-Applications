package com.example.homework4;
public class currentWeatherDetails {
    String maxPredictedTemperatureForTheDay;
    String pressureLevel;
    String temperatureFortheDay;
    String humidityOfTheDay;

    String minPredictedTemperatureForTheDay;

    public String getMaxPredictedTemperatureForTheDay() {
        return maxPredictedTemperatureForTheDay;
    }

    public String getPressureLevel() {
        return pressureLevel;
    }

    public String getTemperatureFortheDay() {
        return temperatureFortheDay;
    }

    public String getHumidityOfTheDay() {
        return humidityOfTheDay;
    }

    public String getMinPredictedTemperatureForTheDay() {
        return minPredictedTemperatureForTheDay;
    }

    public void setMaxPredictedTemperatureForTheDay(String maxPredictedTemperatureForTheDay) {
        this.maxPredictedTemperatureForTheDay = maxPredictedTemperatureForTheDay;
    }

    public void setPressureLevel(String pressureLevel) {
        this.pressureLevel = pressureLevel;
    }

    public void setTemperatureFortheDay(String temperatureFortheDay) {
        this.temperatureFortheDay = temperatureFortheDay;
    }

    public void setHumidityOfTheDay(String humidityOfTheDay) {
        this.humidityOfTheDay = humidityOfTheDay;
    }

    public void setMinPredictedTemperatureForTheDay(String minPredictedTemperatureForTheDay) {
        this.minPredictedTemperatureForTheDay = minPredictedTemperatureForTheDay;
    }

    @Override
    public String toString() {
        return "currentWeatherDetails{" +
                "maxPredictedTemperatureForTheDay='" + maxPredictedTemperatureForTheDay + '\'' +
                ", pressureLevel='" + pressureLevel + '\'' +
                ", temperatureFortheDay='" + temperatureFortheDay + '\'' +
                ", humidityOfTheDay='" + humidityOfTheDay + '\'' +
                ", minPredictedTemperatureForTheDay='" + minPredictedTemperatureForTheDay + '\'' +
                '}';
    }
}

