package com.example.homework4;
import java.util.ArrayList;
public class ForecastDetails {
    ArrayList<weatherTypes> weatherTypes;
    currentWeatherDetails presentWeather;
    windyWeather windCondition;
    CloudyWeather cloudCondition;
    String dates;

    public ArrayList<com.example.homework4.weatherTypes> getWeatherTypes() {
        return weatherTypes;
    }

    public void setWeatherTypes(ArrayList<com.example.homework4.weatherTypes> weatherTypes) {
        this.weatherTypes = weatherTypes;
    }

    public currentWeatherDetails getPresentWeather() {
        return presentWeather;
    }

    public void setPresentWeather(currentWeatherDetails presentWeather) {
        this.presentWeather = presentWeather;
    }

    public windyWeather getWindCondition() {
        return windCondition;
    }

    public void setWindCondition(windyWeather windCondition) {
        this.windCondition = windCondition;
    }

    public CloudyWeather getCloudCondition() {
        return cloudCondition;
    }

    public void setCloudCondition(CloudyWeather cloudCondition) {
        this.cloudCondition = cloudCondition;
    }

    public String getDates() {
        return dates;
    }

    public void setDates(String dates) {
        this.dates = dates;
    }

    @Override
    public String toString() {
        return "ForecastDetails{" +
                "weatherTypes=" + weatherTypes +
                ", presentWeather=" + presentWeather +
                ", windCondition=" + windCondition +
                ", cloudCondition=" + cloudCondition +
                ", dates='" + dates + '\'' +
                '}';
    }
}

