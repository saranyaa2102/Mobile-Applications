package com.example.homework4;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.view.LayoutInflater;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import com.squareup.picasso.Picasso;
import android.widget.TextView;

public class ForecastAdapter extends RecyclerView.Adapter<ForecastAdapter.forecastValue>{
    ArrayList<ForecastDetails> currentTemperature;
    public ForecastAdapter(ArrayList<ForecastDetails> details) {
        this.currentTemperature = details;
    }
    @NonNull
    @Override
    public forecastValue onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.forecast_adapter, parent, false);
        forecastValue viewHolder = new forecastValue(view);
        return viewHolder;
    }
    @Override
    public void onBindViewHolder(@NonNull forecastValue holder, int position) {

        ForecastDetails details = currentTemperature.get(position);
        String icon = details.getWeatherTypes().get(0).getClimaticConditionIcon();
        String url = "https://openweathermap.org/img/wn/" + icon + "@2x.png";
        holder.date.setText(details.getDates());
        holder.minimumTemperature.setText("Min: " + details.getPresentWeather().getMinPredictedTemperatureForTheDay() + " F");
        holder.maximumTemperature.setText("Max: " + details.getPresentWeather().getMaxPredictedTemperatureForTheDay() + " F");
        holder.Temperature.setText(details.getPresentWeather().getTemperatureFortheDay() + " F");
        holder.description.setText(details.getWeatherTypes().get(0).getDesc());
        holder.humidityValue.setText(details.getPresentWeather().getHumidityOfTheDay() + "%");
        Picasso.get()
                .load(url)
                .into(holder.icon);
    }
    @Override
    public int getItemCount() {
        return currentTemperature.size();
    }
    public static class forecastValue extends RecyclerView.ViewHolder{
        TextView date;
        TextView Temperature;
        TextView maximumTemperature;
        TextView minimumTemperature;
        TextView humidityValue;
        TextView description;
        ImageView icon;
        public forecastValue(@NonNull View itemView) {
            super(itemView);
            date = itemView.findViewById(R.id.foreCastDate);
            Temperature = itemView.findViewById(R.id.ForecastCurrentTemperature);
            maximumTemperature = itemView.findViewById(R.id.ForecastMaxTemperature);
            minimumTemperature = itemView.findViewById(R.id.ForecastMinTemperature);
            humidityValue = itemView.findViewById(R.id.ForecastHumidity);
            description = itemView.findViewById(R.id.ForecastDescription);
            icon = itemView.findViewById(R.id.ForecastWeatherIcon);
        }
    }
}
