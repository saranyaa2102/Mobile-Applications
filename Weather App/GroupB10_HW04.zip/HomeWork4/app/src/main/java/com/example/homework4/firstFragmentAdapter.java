package com.example.homework4;

import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class firstFragmentAdapter extends RecyclerView.Adapter<firstFragmentAdapter.citiesValue>{
    ArrayList<Data.City> citiesListing;
    AdapterInterface citiesAdapter;
    public firstFragmentAdapter(ArrayList<Data.City> cities, AdapterInterface adapterInterface){
        this.citiesListing = cities;
        this.citiesAdapter = adapterInterface;
    }
    @NonNull
    @Override
    public citiesValue onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(android.R.layout.simple_list_item_1, parent, false);
        citiesValue viewHolder = new citiesValue(view, citiesAdapter);
        return viewHolder;
    }
    @Override
    public void onBindViewHolder(@NonNull citiesValue holder, int cityIndex) {
        Data.City NameOfCity = citiesListing.get(cityIndex);
        holder.cityHolder.setText(NameOfCity.getCity() + ", " + NameOfCity.getCountry());
        holder.cityIndex = cityIndex;
        holder.cityName = NameOfCity;
    }
    @Override
    public int getItemCount() {
        return citiesListing.size();
    }
    public static class citiesValue extends RecyclerView.ViewHolder{
        TextView cityHolder;
        int cityIndex;
        Data.City cityName;
        AdapterInterface citiesAdapter;
        public citiesValue(@NonNull View itemView, AdapterInterface citiesAdapter) {
            super(itemView);
            cityHolder = itemView.findViewById(android.R.id.text1);
            this.citiesAdapter = citiesAdapter;
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    citiesAdapter.passDataToCityFragment(cityName);
                }
            });
        }
    }
    interface AdapterInterface{
        void passDataToCityFragment(Data.City cityName);
    }
}
