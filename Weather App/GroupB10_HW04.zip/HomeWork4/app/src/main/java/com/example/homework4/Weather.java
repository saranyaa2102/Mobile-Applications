package com.example.homework4;
import com.squareup.picasso.Picasso;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.view.LayoutInflater;
import android.view.View;
import java.io.IOException;
import java.util.ArrayList;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import android.widget.Toast;

public class Weather extends Fragment {
    private static final String CITY = "CITY";
    private static final String key = "key";
    Data.City cityName;
    String account_key;
    weatherInterface weather;
    TextView city;
    TextView temperature;
    TextView MaxTemperature;
    TextView MinTemperature;
    TextView description;
    TextView humidity;
    TextView speed;
    TextView degree;
    TextView cloudiness;
    ImageView Icon;

    public Weather() {
    }

    public static Weather newInstance(Data.City cityValue, String cityIndex) {
        Weather fragment = new Weather();
        Bundle args = new Bundle();
        args.putSerializable(CITY, cityValue);
        args.putString(key, cityIndex);
        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            cityName = (Data.City) getArguments().getSerializable(CITY);
            account_key = getArguments().getString(key);
        }
    }
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof weatherInterface){
            weather = (weatherInterface) context;
        }
        else {
            throw new RuntimeException(getContext().toString());
        }
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.weather, container, false);
        getActivity().setTitle(getResources().getString(R.string.secondFragmentTitle));
        city = view.findViewById(R.id.WeatherCityName);
        temperature = view.findViewById(R.id.weatherTemperatureValue);
        MaxTemperature = view.findViewById(R.id.WeatherMaximumTemperatureValue);
        MinTemperature = view.findViewById(R.id.WeatherMinimumTemperatureValue);
        description = view.findViewById(R.id.WeatherDescriptionValue);
        humidity = view.findViewById(R.id.WeatherHumidityValue);
        speed = view.findViewById(R.id.WeatherWindSpeedValue);
        degree = view.findViewById(R.id.WeatherWindDegreeValue);
        cloudiness = view.findViewById(R.id.WeatherCloudinessValue);
        Icon = view.findViewById(R.id.WeatherIcon);
        view.findViewById(R.id.ForecastButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                weather.weatherForecast(cityName);
            }
        });
        new GetCurrentWeatherData().execute(cityName.getCity(), cityName.getCountry(), account_key);
        return view;
    }
    class GetCurrentWeatherData extends AsyncTask<String, Integer, ForecastDetails>{
        final OkHttpClient client = new OkHttpClient();
        String receivedCityName, receivedCountryName;
        @Override
        protected ForecastDetails doInBackground(String... strings) {
            receivedCityName = strings[0];
            receivedCountryName = strings[1];
            HttpUrl url = HttpUrl.parse("https://api.openweathermap.org/data/2.5/weather").newBuilder()
                    .addQueryParameter("q", strings[0])
                    .addQueryParameter("appid", strings[2])
                    .addQueryParameter("units", "imperial")
                    .build();
            Request req = new Request.Builder()
                    .url(url)
                    .build();
            ForecastDetails details = new ForecastDetails();
            try {
                Response response = client.newCall(req).execute();
                if (response.isSuccessful()){
                    weatherTypes weather = new weatherTypes();
                    ArrayList<weatherTypes> weatherResults = new ArrayList<>();
                    windyWeather windCondition = new windyWeather();
                    currentWeatherDetails currentWeatherResults = new currentWeatherDetails();
                    CloudyWeather cloudCondition = new CloudyWeather();
                    JSONObject object = new JSONObject(response.body().string());
                    JSONArray weathers = object.getJSONArray("weather");
                    JSONObject weatherObject = weathers.getJSONObject(0);
                    JSONObject currentTempObject = object.getJSONObject("main");
                    JSONObject windObject = object.getJSONObject("wind");
                    JSONObject cloudObject = object.getJSONObject("clouds");
                    weather.setDesc(weatherObject.getString("description"));
                    weather.setClimaticConditionIcon(weatherObject.getString("icon"));
                    weatherResults.add(weather);
                    currentWeatherResults.setTemperatureFortheDay(currentTempObject.getString("temp"));
                    currentWeatherResults.setMaxPredictedTemperatureForTheDay(currentTempObject.getString("temp_max"));
                    currentWeatherResults.setMinPredictedTemperatureForTheDay(currentTempObject.getString("temp_min"));
                    currentWeatherResults.setHumidityOfTheDay(currentTempObject.getString("humidity"));
                    currentWeatherResults.setPressureLevel(currentTempObject.getString("pressure"));
                    windCondition.setDegree(windObject.getString("deg"));
                    windCondition.setWindSpeed(windObject.getString("speed"));
                    cloudCondition.setCloudyWeather(cloudObject.getString("all"));
                    details.setPresentWeather(currentWeatherResults);
                    details.setWeatherTypes(weatherResults);
                    details.setWindCondition(windCondition);
                    details.setCloudCondition(cloudCondition);
                }
            } catch (IOException | JSONException e) {
                e.printStackTrace();
            }
            return details;
        }
        @Override
        protected void onPostExecute(ForecastDetails totalTemperatureData) {
            if (totalTemperatureData != null){
                String icon = totalTemperatureData.getWeatherTypes().get(0).getClimaticConditionIcon();
                String iconUrl = "https://openweathermap.org/img/wn/" + icon + "@2x.png";
                city.setText(receivedCityName + ", " + receivedCountryName);
                temperature.setText(totalTemperatureData.presentWeather.getTemperatureFortheDay() + " F");
                MaxTemperature.setText(totalTemperatureData.presentWeather.getMaxPredictedTemperatureForTheDay() + " F");
                MinTemperature.setText(totalTemperatureData.presentWeather.getMinPredictedTemperatureForTheDay() + " F");
                description.setText(totalTemperatureData.weatherTypes.get(0).desc);
                humidity.setText(totalTemperatureData.presentWeather.getHumidityOfTheDay() + "%");
                speed.setText(totalTemperatureData.windCondition.getWindSpeed() + " miles/hr");
                degree.setText(totalTemperatureData.windCondition.getDegree() + " degrees");
                cloudiness.setText(totalTemperatureData.cloudCondition.getCloudyWeather() + " %");
                Picasso.get()
                        .load(iconUrl)
                        .into(Icon);
            }
            else {
                Toast.makeText(getContext(), getResources().getString(R.string.Warning), Toast.LENGTH_SHORT).show();
            }
        }
    }
    interface weatherInterface{
        void weatherForecast(Data.City city);
    }
}
