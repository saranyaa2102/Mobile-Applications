package com.example.homework4;
//Kamalapriya Srinivasan
//Saranyaa Thirumoorthy
//GroupB10
//HomeWork 4

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import okhttp3.OkHttpClient;

public class MainActivity extends AppCompatActivity implements firstFragment.firstFragmentInterface, Weather.weatherInterface{
    public static final String key = "703d5377265176f5a7cee1b6baa48c30";
    private final OkHttpClient client = new OkHttpClient();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportFragmentManager().beginTransaction()
                .add(R.id.rootView, new firstFragment())
                .commit();
    }
    @Override
    public void TodayWeather(Data.City city) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, Weather.newInstance(city, key))
                .addToBackStack(null)
                .commit();
    }
    @Override
    public void weatherForecast(Data.City city) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, Forecast.newInstance(city, key))
                .addToBackStack(null)
                .commit();
    }
}