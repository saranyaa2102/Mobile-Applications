package com.example.homework4;
import android.view.View;
import android.view.ViewGroup;
import android.content.Context;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import android.os.Bundle;

public class firstFragment extends Fragment implements firstFragmentAdapter.AdapterInterface{
    RecyclerView cities;
    LinearLayoutManager citiesLayout;
    firstFragmentAdapter citiesAdapter;
    firstFragmentInterface citiesInt;

    public firstFragment() {
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof firstFragmentInterface){
            citiesInt = (firstFragmentInterface) context;
        }
        else{
            throw new RuntimeException(getContext().toString());
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.first_fragment, container, false);
        getActivity().setTitle(getResources().getString(R.string.firstFragmentTitle));
        cities = view.findViewById(R.id.cityListing);
        cities.setHasFixedSize(true);
        citiesLayout = new LinearLayoutManager(getContext());
        cities.setLayoutManager(citiesLayout);
        citiesAdapter = new firstFragmentAdapter(Data.cities, this);
        cities.setAdapter(citiesAdapter);
        return view;
    }

    @Override
    public void passDataToCityFragment(Data.City cities) {
        citiesInt.TodayWeather(cities);
    }
    interface firstFragmentInterface{
        void TodayWeather(Data.City cities);
    }
}
