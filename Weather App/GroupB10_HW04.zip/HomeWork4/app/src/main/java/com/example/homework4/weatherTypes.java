package com.example.homework4;

public class weatherTypes {
    String desc;
    String climaticConditionIcon;


    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getClimaticConditionIcon() {
        return climaticConditionIcon;
    }

    public void setClimaticConditionIcon(String climaticConditionIcon) {
        this.climaticConditionIcon = climaticConditionIcon;
    }

    @Override
    public String toString() {
        return "weatherTypes{" +
                "desc='" + desc + '\'' +
                ", climaticConditionIcon='" + climaticConditionIcon + '\'' +
                '}';
    }
}