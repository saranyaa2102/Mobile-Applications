//Inclass04
//GroupB10
//Saranyaa Thirumoorthy
//Kamalapriya Srinivasan
//iTunesAdapter.java



package com.example.inclass4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.List;


public class iTunesAdapter extends ArrayAdapter<DataServices.App> {
    public iTunesAdapter(@NonNull Context context, int resource, @NonNull List<DataServices.App> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if (convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.adapter , parent, false);
            ViewHolder viewHolder = new ViewHolder();
            viewHolder.appNameLayout = convertView.findViewById(R.id.appName);
            viewHolder.artistNameLayout = convertView.findViewById(R.id.ArtistName);
            viewHolder.releaseDateLayout = convertView.findViewById(R.id.Date);
            convertView.setTag(viewHolder);
        }
        DataServices.App Data = getItem(position);
        ViewHolder viewHolder = (ViewHolder) convertView.getTag();
        viewHolder.appNameLayout.setText(Data.name);
        viewHolder.artistNameLayout.setText(Data.artistName);
        viewHolder.releaseDateLayout.setText(Data.releaseDate);
        return convertView;
    }

    private static class ViewHolder{
        TextView appNameLayout, artistNameLayout, releaseDateLayout;
    }

}
