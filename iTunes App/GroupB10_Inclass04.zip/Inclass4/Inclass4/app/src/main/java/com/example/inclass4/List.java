
//List.java
//Inclass04
//GroupB10
//Saranyaa Thirumoorthy
//Kamalapriya Srinivasan




package com.example.inclass4;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class List extends Fragment {

    private static final String ARG_TOKEN = "TOKEN";
    private static final String ARG_CATEGORY_NAME = "CATEGORY_NAME";

    private String Category;
    ArrayList<DataServices.App> appArrayList;
    private String token;
    ListView list;
    ListInterface listsinterface;
    iTunesAdapter iTunes;

    public List() {
    }

    // TODO: Rename and change types and number of parameters
    public static List newInstance(String token, String categoryName) {
        List fragment = new List ();
        Bundle args = new Bundle();
        args.putString(ARG_TOKEN, token);
        args.putString(ARG_CATEGORY_NAME, categoryName);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            token = getArguments().getString(ARG_TOKEN);
            Category = getArguments().getString(ARG_CATEGORY_NAME);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.list , container, false);
        list = view.findViewById(R.id.AppsListing );
        getActivity().setTitle(Category);

        DataServices.getAppsByCategory(token, Category, new DataServices.DataResponse<DataServices.App>() {
            @Override
            public void onSuccess(ArrayList<DataServices.App> data) {
                appArrayList = data;
                iTunes = new iTunesAdapter (getActivity(), R.layout.adapter , appArrayList);
                list.setAdapter(iTunes);
            }
            @Override
            public void onFailure(DataServices.RequestException exception) {
                listsinterface.writeToast(exception.getMessage());
            }
        });

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                DataServices.App appData = appArrayList.get(position);
                listsinterface.Details(appData);
            }
        });
        return view;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof ListInterface){
            listsinterface = (ListInterface) context;
        }
        else {
            throw new RuntimeException(getContext().toString());
        }
    }
    public interface ListInterface {
        public void Details(DataServices.App appData);

        void writeToast(String message);
    }


}