//Inclass04
//Register.java
//GroupB10
//Saranyaa Thirumoorthy
//Kamalapriya Srinivasan



package com.example.inclass4;

import android.graphics.Color;
import android.icu.text.CaseMap;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.content.Context;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.widget.Toast;
import androidx.annotation.NonNull;

public class Register extends Fragment {
    EditText Name, Email, Password;
    registerInterface register;
    public Register() {
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.register , container, false);
        Email = view.findViewById(R.id.RegisterEmail );
        Name = view.findViewById(R.id.RegisterName );
        Password = view.findViewById(R.id.RegisterPassword );

        view.findViewById(R.id.submit ).setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Name.getText().toString().isEmpty() || Email.getText().toString().isEmpty() || Password.getText().toString().isEmpty()){
                    register.writeToast(getString(R.string.missingFields));
                }else {
                    DataServices.register(Name.getText().toString(), Email.getText().toString(), Password.getText().toString(), new DataServices.AuthResponse() {
                        @Override
                        public void onSuccess(String token) {
                            register.CreateAccount(token);
                        }
                        @Override
                        public void onFailure(DataServices.RequestException exception) {
                            register.writeToast(exception.getMessage());
                        }
                    });
                }
            }
        });

        view.findViewById(R.id.Cancel ).setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                register.CancelRegistration();
            }
        });
        return view;
        }

        @Override
        public void onAttach(@NonNull Context context) {
            super.onAttach(context);
            if (context instanceof registerInterface){
                register = (registerInterface) context;
            }
            else {
                throw new RuntimeException(context.toString());
            }
        }
        public interface registerInterface{
            public void CancelRegistration();
            public void CreateAccount(String token);

            void writeToast(String message);
        }
}