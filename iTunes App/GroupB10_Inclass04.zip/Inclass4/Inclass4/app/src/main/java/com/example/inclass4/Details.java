//Inclass04
//GroupB10
//Saranyaa Thirumoorthy
//Kamalapriya Srinivasan
//Details.java




package com.example.inclass4;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class Details extends Fragment {
    private static final String ARG_APP_DATA = "APP_DATA";
    DataServices.App appDetails;
    TextView Name, Artist, Date;
    ListView Genre;
    ArrayAdapter<String> arrayAdapter;


    public Details() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static Details newInstance(DataServices.App appData) {
        Details fragment = new Details ();
        Bundle args = new Bundle();
        args.putSerializable(ARG_APP_DATA, appData);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            appDetails = (DataServices.App) getArguments().getSerializable(ARG_APP_DATA);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.details , container, false);

        Genre = v.findViewById(R.id.applist );
        Name = v.findViewById(R.id.Name );
        Artist = v.findViewById(R.id.artist );
        Date = v.findViewById(R.id.date );

        Name.setText(String.valueOf(appDetails.name));
        Artist.setText(String.valueOf(appDetails.artistName));
        Date.setText(String.valueOf(appDetails.releaseDate));

        arrayAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, android.R.id.text1, appDetails.genres);
        Genre.setAdapter(arrayAdapter);
        return v;
    }
}