//Inclass04
//MainActivity.java
//GroupB10
//Saranyaa Thirumoorthy
//Kamalapriya Srinivasan




package com.example.inclass4;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements Login.loginInterface, Register.registerInterface, Categories.CategoriesInterface, List.ListInterface {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportFragmentManager().beginTransaction()
                .add(R.id.rootView , new Login ()) //on create, display login fragment
                .commit();
        setTitle(getString(R.string.login));
    }
    @Override
    public void CreateAccount(String token) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView , Categories.newInstance(token)) //After successful registration, display app categories page
                .commit();
    }
    @Override
    public void List(String token, String categoryName) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView , List.newInstance(token, categoryName), categoryName) //displaying the list of apps based on categories
                .addToBackStack(null)
                .commit();
    }
    @Override
    public void Register() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView , new Register ()) // registration fragment
                .commit();
        setTitle(getString(R.string.register));
    }
    @Override
    public void CancelRegistration() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView , new Login ()) // cancel registration and return to login screen
                .commit();
    }
    @Override
    public void logout() {
        getSupportFragmentManager().popBackStack();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView , new Login ()) // logout to return to login screen
                .commit();
        setTitle(getString(R.string.login));
    }
    @Override
    public void login(String token) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView , Categories.newInstance(token)) // login fragment
                .commit();
        setTitle(getString(R.string.login));
    }
    @Override
    public void Details(DataServices.App appData) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView , Details.newInstance(appData)) // Display app details fragment
                .addToBackStack(null)
                .commit();
        setTitle(getString(R.string.Details));
    }

    @Override
    public void writeToast(String message){
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }
}