//Inclass04
//GroupB10
//Saranyaa Thirumoorthy
//Kamalapriya Srinivasan
//Categories.java




package com.example.inclass4;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;


public class Categories extends Fragment {

    private static final String ARG_TOKEN = "TOKEN";
    private String token;
    ListView CategoriesView;
    DataServices.Account matchingAccount;
    TextView greeting;
    CategoriesInterface categoriesInterface;
    ArrayList<String> Categories;
    ArrayAdapter<String> adapter;


    public Categories() {
    }

    // TODO: Rename and change types and number of parameters
    public static Categories newInstance(String token) {
        Categories fragment = new Categories ();
        Bundle args = new Bundle();
        args.putString(ARG_TOKEN, token);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            this.token = getArguments().getString(ARG_TOKEN);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.categories, container, false);
        CategoriesView = view.findViewById(R.id.categories);
        greeting = view.findViewById(R.id.greeting);
        getActivity().setTitle(R.string.categories);
        DataServices.getAccount(token, new DataServices.AccountResponse() {
            @Override
            public void onSuccess(DataServices.Account account) {
                matchingAccount = account;
            }
            @Override
            public void onFailure(DataServices.RequestException exception) {
                categoriesInterface.writeToast(exception.getMessage());
            }
        });

        if (matchingAccount != null){
            greeting.setText("Welcome " + matchingAccount.getName());
        }
        DataServices.getAppCategories(token, new DataServices.DataResponse<String>() {
            @Override
            public void onSuccess(ArrayList<String> data) {
                Categories = data;
                adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, android.R.id.text1, Categories);
                CategoriesView.setAdapter(adapter);
            }
            @Override
            public void onFailure(DataServices.RequestException exception) {
                categoriesInterface.writeToast(exception.getMessage());
            }
        });

        CategoriesView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                categoriesInterface.List(token, Categories.get(position));
            }
        });

        view.findViewById(R.id.Logout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                categoriesInterface.logout();
            }
        });

        return view;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof CategoriesInterface){
            categoriesInterface = (CategoriesInterface) context;
        }
        else {
            throw new RuntimeException( String.valueOf ( getContext() ) );
        }
    }

    public interface CategoriesInterface{
        public void logout();
        public void List(String token, String categoryName);

        void writeToast(String message);
    }
}