//Inclass04
//Login.java
//GroupB10
//Saranyaa Thirumoorthy
//Kamalapriya Srinivasan



package com.example.inclass4;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.content.Context;
import android.os.Bundle;

import android.widget.Toast;


public class Login extends Fragment {

    EditText Email, Password;
    loginInterface login;

    public Login() {

    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.login , container, false);
        Email = v.findViewById(R.id.Email );
        Password = v.findViewById(R.id.Password );

        v.findViewById(R.id.Login).setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if ( Email.getText().toString().isEmpty () || Password.getText().toString().isEmpty ()){
                    login.writeToast(getString(R.string.emptyfields));
                }
                else{
                    //Call login method from DataServices File
                    DataServices.login(Email.getText().toString(), Password.getText().toString(), new DataServices.AuthResponse() {
                        @Override
                        public void onSuccess(String token) { // On Matching creditials in DataServices File, Login
                            login.login(token);
                        }

                        @Override
                        public void onFailure(DataServices.RequestException exception) { // On mismatched credentials from Data Services File, Avoid Login
                             login.writeToast(exception.getMessage());
                        }
                    });
                }
            }
        });

        v.findViewById(R.id.NewAccount).setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login.Register();
            }
        });
        return v;
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof loginInterface){
            login = (loginInterface) context;
        }
        else{
            throw new RuntimeException(context.toString());
        }
    }

    public interface loginInterface{
        public void Register();
        public void login(String token);

        void writeToast(String message);
    }

}
