//a.Assignment : Home Work 01
// b.File Name: MainActivity.java
// c. Group: 10
//d. Saranyaa Thirumoorthy, Gowri Alwarsamy



package com.example.group10_hw01;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    SeekBar seekBar;
    RadioGroup radioGroup;
    TextView seekBarPercent, totalTextView, tipTextView;
    EditText billTotalField;
    Button buttonCloseApp;

    float tipPercent = 0;
    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        seekBar = findViewById(R.id.seekBar);
        totalTextView = findViewById(R.id.totalTextView);
        tipTextView = findViewById(R.id.tipTextView);
        buttonCloseApp = findViewById(R.id.buttonCloseApp);
        seekBarPercent = findViewById(R.id.seekBarPercent);
        billTotalField = findViewById(R.id.billTotalField);
        buttonCloseApp.setBackgroundColor(Color.LTGRAY);
        radioGroup = findViewById(R.id.radio_group);
        seekBarPercent = findViewById(R.id.seekBarPercent);
        seekBar.setProgress(20 * 2);
        buttonCloseApp.setTextColor(Color.BLACK);
        seekBarPercent.setText(getString(R.string.percent20));

        //5. Exit Button
        buttonCloseApp.setOnClickListener(view -> {
            final AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Exit Alert!");
            builder.setMessage("Want to exit the app?");
            builder.setPositiveButton("Yes", (dialogInterface, i) -> finish());
            builder.setNegativeButton("No", (dialogInterface, i) -> dialogInterface.dismiss());
            AlertDialog dialog = builder.create();
            dialog.show();
        });

        //1. Tip Calculator based on the selected radio button
        RadioGroup radioGroup = findViewById(R.id.radio_group);
        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            switch (checkedId) {
                case R.id.tip10percent:
                    tipPercent = 10;
                    calculateTip(tipPercent);
                    break;
                case R.id.tip15percent:
                    tipPercent = 15;
                    calculateTip(tipPercent);
                    break;
                case R.id.tip18percent:
                    tipPercent = 18;
                    calculateTip(tipPercent);
                    break;
                case R.id.customPercent:
                    //4. Custom Seek bar display and Tip calculation
                    seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                        @SuppressLint("SetTextI18n")
                        @Override
                        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                            seekBarPercent.setText(progress / 2 + "%");
                            float tipPercent = ((float) progress / 2);
                            calculateTip(tipPercent);
                        }

                        @Override
                        public void onStartTrackingTouch(SeekBar seekBar) {
                        }

                        @Override
                        public void onStopTrackingTouch(SeekBar seekBar) {

                        }
                    });
                    break;
            }
        });

        //2.Tip Calculator for the updates or edits made to bill total
        //3.setting the tip and total bill to empty and display toast message "Enter Bill total"
        billTotalField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String TB = billTotalField.getText().toString().trim();
                if (!TB.isEmpty()) {
                    if (radioGroup.getCheckedRadioButtonId() != R.id.customPercent) {
                        try {
                            String billTotalStr = String.valueOf(billTotalField.getText());
                            float billTotal = Float.parseFloat(billTotalStr);
                            float tip = (float) (tipPercent / 100.0 * billTotal);
                            float finalTotal = billTotal + tip;
                            tipTextView.setText(String.valueOf(tip));
                            totalTextView.setText(String.valueOf(finalTotal));
                        } catch (NumberFormatException e) {
                            Toast.makeText(MainActivity.this, getString(R.string.invalid), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        try {
                            int progress = seekBar.getProgress();
                            int tipPercent = progress / 2;
                            String billTotalStr = String.valueOf(billTotalField.getText());
                            float billTotal = Float.parseFloat(billTotalStr);
                            float tip = (float) (tipPercent / 100.0 * billTotal);
                            float finalTotal = billTotal + tip;
                            tipTextView.setText(String.valueOf(tip));
                            totalTextView.setText(String.valueOf(finalTotal));
                        } catch (NumberFormatException e) {
                            Toast.makeText(MainActivity.this, getString(R.string.invalid), Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    tipTextView.setText("");
                    totalTextView.setText("");
                    Toast.makeText(getApplicationContext(),"Enter Bill Total",Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    //Common Tip Calculator function
    public void calculateTip(float tipPercent) {
        try {
            String billTotalStr = String.valueOf(billTotalField.getText());
            float billTotal = Float.parseFloat(billTotalStr);
            float tip = (float) (tipPercent / 100.0 * billTotal);
            float finalTotal = billTotal + tip;
            tipTextView.setText(String.valueOf(tip));
            totalTextView.setText(String.valueOf(finalTotal));
        } catch (NumberFormatException e) {
            Toast.makeText(MainActivity.this, getString(R.string.invalid), Toast.LENGTH_SHORT).show();
        }
    }

}
